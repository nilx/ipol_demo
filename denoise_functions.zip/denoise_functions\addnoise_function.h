#ifndef _ADD_NOISE_FUNCTION_H_
#define _ADD_NOISE_FUNCTION_H_


/* addnoise_function.cpp */
#include <cmath>

void fiAddNoise(float *u, float *v, float std, long int randinit, int size);

