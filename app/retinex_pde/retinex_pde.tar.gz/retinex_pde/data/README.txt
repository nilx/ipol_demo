Adelson.svg
* file from Wikimedia Commons
  http://commons.wikimedia.org/wiki/File:Grey_square_optical_illusion.svg
* vectorized version of the original Adelson Image
  http://web.mit.edu/persci/people/adelson/checkershadow_illusion.html
* The copyright holder of this work allows anyone to use it for any
  purpose including unrestricted redistribution, commercial use, and
  modification.

Adelson.png
* raster rendering of Adelson.svg

color.png, noisy.png
* created by Ana Belén Petro and Catalina Sbert
* licenced CC-BY
