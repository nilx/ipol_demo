/**
* @brief normalize an input image  given the mean and the varianze
*
* Given the mean value M and the stardard deviation DT. We apply an affine transformations to the input image
* such that the new image has mean value M and standard deviation DT
*
* @param p input data
* @param M the mean value
* @param DT standard deviation
* @param dim dimension of the input
* @param F output data
*
* @return F
*/





float *norm_dt( float *F, float *p, float M, float DT, size_t dim )

{
 
      float m,d,a,b;
      float *prt_in, *ptr_out,*ptr_end;
     

      /* sanity check*/
       if (NULL == F || NULL == p)
       {
        fprintf(stderr, "a pointer is NULL and should not be so\n");
        abort();
       }

     m=0.;
     ptr_in=p;
     ptr_end=p+dim;
     while(ptr_in < ptr_end){
       m+=*ptr_in;
       ptr_in++;}
    m/=dim;
    d=0.;
    ptr_in=p;
     while(ptr_in < ptr_end){
     d+=(*ptr_in-m)*(*ptr_in-m); ptr_in++;
     }
     d/=dim;
     d=(float)sqrt((double)d);
     a=DT/d; b=M-a*m;
     ptr_out=F;
     ptr_in=p;
    while(ptr_in < ptr_end){
      *ptr_out=a*(*ptr_in)+b;
       ptr_out++; ptr_in++;
    }

     return F;


}