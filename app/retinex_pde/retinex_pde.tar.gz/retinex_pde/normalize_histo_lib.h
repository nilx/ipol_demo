/* normalize_histo_lib.c */
float *normalize_histo_f32(float *data, size_t size, float target_min, float target_max, size_t flat_nb_min, size_t flat_nb_max);
