#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "fimage.h"


/* min-filter the input with correlation corr, and generates a new
 * disparity map with correlation newcorr.
 * The size of the window is given by w.
 * If mask!=NULL then only the nonzero pixels are considered by the filter.*/
void minfilter_angulo(Fimage in_disp, Fimage in_cost, Fimage in_argmin,
					Fimage out_disp, Fimage out_cost, Fimage out_argmin,
					int w, Fimage mask)
{
  int y,x,i,j;
  int N = in_disp->ncol*in_disp->nrow;
  int nc = in_disp->ncol, nr =in_disp->nrow;
  int nch = in_disp->nch, nch2 = in_cost->nch;
  float tilt, shear, disp;

  /* in case the window size is not odd, we must adapt the right limit.
   * This is because the correlation treats the even windows as if their center O
   * is displaced towards right:  xxxOxx */
  int wl=w/2;
  int wr=w/2;
  if(w%2==0) wr--;

  if(nch>1 || nch2>1) {
     fprintf(stderr, "minfilter_angulo: only considering the first channel of input disp and corr\n");
  }

  // TODO: out SHOULD BE SET TO -1000 because the output of minfilter may be incorrect at some points.
  for(i=0;i<nr*nc;i++) out_disp->gray[i] = in_disp->gray[i*nch];
  for(i=0;i<nr*nc;i++) out_cost->gray[i] = in_cost->gray[i*nch2];
  for(i=0;i<2*nr*nc;i++) out_argmin->gray[i] = in_argmin->gray[i]; // argmin has 2 channels


  for(y=wl;y<nr-wr;y++)
     for(x=wl;x<nc-wr;x++)
     {
        float curr_cost = 100000000;
        int pos = x+y*nc;
        for(i=-wl;i<=wr;i++)
           for(j=-wl;j<=wr;j++)
           {
              int posW = x+i + (y+j)*nc;
              if ( curr_cost > in_cost->gray[posW*nch2] && mask && mask->gray[posW] )
              {
                 curr_cost = in_cost->gray[posW*nch2];
                 disp = in_disp->gray[posW*nch];
                 tilt = in_argmin->gray[posW*2];
                 shear = in_argmin->gray[posW*2+1];

                 out_cost->gray[pos] = curr_cost;
                 out_argmin->gray[pos*2] = tilt;
				 out_argmin->gray[pos*2+1] = shear;
                 out_disp->gray[pos] = disp + shear*j-(1.0-1.0/tilt)*i;
              }
           }
     }

}
