#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "fimage.h"


/* min-filter the input with correlation corr, and generates a new 
 * disparity map with correlation newcorr. 
 * The size of the window is given by w.
 * If mask!=NULL then only the nonzero pixels are considered by the filter.*/
void minfilter(Fimage in, Fimage corr, Fimage out, Fimage newcorr, int w, Fimage mask)
{
  int y,x,i,j;
  int N = in->ncol*in->nrow;
  int nc = in->ncol, nr =in->nrow;
  int nch = in->nch, nch2 = corr->nch;

  /* in case the window size is not odd, we must adapt the right limit.
   * This is because the correlation treats the even windows as if their center O
   * is displaced towards right:  xxxOxx */
  int wl=w/2;
  int wr=w/2;
  if(w%2==0) wr--;

  if(nch>1 || nch2>1) {
     fprintf(stderr, "minfilter: only considering the first channel of each input\n");
  }

  // TODO: out SHOULD BE SET TO -1000 because the output of minfilter may be incorrect at some points.
  for(i=0;i<nr*nc;i++) out->gray[i]     = in->gray[i*nch];
  for(i=0;i<nr*nc;i++) newcorr->gray[i] = corr->gray[i*nch2];

  for(y=wl;y<nr-wr;y++) 
     for(x=wl;x<nc-wr;x++) {
        float currcorr=100000000;
        int pos = x+y*nc;
        for(i=-wl;i<=wr;i++) 
           for(j=-wl;j<=wr;j++) {
              int posW = x+i + (y+j)*nc;
              if ( currcorr > corr->gray[posW*nch2] && mask && mask->gray[posW] ) {
                 currcorr = corr->gray[posW*nch2];
                 newcorr->gray[pos]=currcorr;
                 out->gray[pos] = in->gray[posW*nch];
              }
           }
     }

}

// old minfilter without mask
//void minfilter(Fimage in, Fimage best, Fimage out, Fimage newbest, int w)
//{
//  int y,x,i,j;
//  int N = in->ncol*in->nrow;
//  int nc = in->ncol, nr =in->nrow;
//
//  /* in case the window size is not odd, we must adapt the right limit.
//   * This is because the correlation treats the even windows as if their center O
//   * is displaced towards right:  xxxOxx */
//  int wl=w/2;
//  int wr=w/2;
//  if(w%2==0) wr--;
//
//  if(in->nch>1 || best->nch>1) abort();
//
//  for(i=0;i<nr*nc;i++) out->gray[i]     = in->gray[i];
//  for(i=0;i<nr*nc;i++) newbest->gray[i] = best->gray[i];
//
//  for(y=wl+1;y<nr-wr-1;y++) 
//     for(x=wl+1;x<nc-wr-1;x++) {
//        float currbest=100000000;
//        for(i=-wl;i<=wr;i++) 
//           for(j=-wl;j<=wr;j++) {
//              if (currbest > best->gray[x+i + (y+j)*nc]) {
//                 currbest = best->gray[x+i + (y+j)*nc];
//                 newbest->gray[x+y*nc]=currbest;
//                 out->gray[x+y*nc] = in->gray[x+i + (y+j)*nc];
//              }
//           }
//     }
//
//}






/* MAIN  */

#ifndef DONT_USE_MAIN

#include "iio.h"
#include "smartparameter.h"

SMART_PARAMETER(MASK_THRES,1)


Fimage fimageread(char* name) 
{
   int nx,ny,nc;
   float *disp = iio_read_image_float_vec(name, &nx, &ny, &nc);
   return new_fimage3(disp, nx,ny,nc);
}

void fimagewrite(char* name, Fimage i) 
{
   iio_save_image_float_vec(name, i->gray, i->ncol, i->nrow, i->nch);
}



int main (int argc, char **argv)
{
   int w = 7;
   int nx,ny,nch;
   char *disp_file    = NULL;
   char *corr_file    = NULL;
   char *outdisp_file = NULL;
   char *outcorr_file = NULL;
   char *changed_file = NULL;

   /* ppatameter parsing - parameters*/
   if(argc<6) 
   {
      fprintf(stderr,"too few parameters\n");
      fprintf(stderr,"Min filter\n");
      fprintf(stderr,"usage: minfilter window_size disparity correlation output_disparity output_correlation [change_mask] [mask1] [mask2] ...\n");
      fprintf(stderr,"       change_mask is |MF(disp) - disp| > MASK_THRES\n");
      fprintf(stderr,"       Use the enviroment variable MASK_THRES=thres to modify threshold (default=1).\n");
      return 1;
   }

   w            = atoi (argv[1]);
   disp_file    = argv[2];
   corr_file    = argv[3];
   outdisp_file = argv[4];
   outcorr_file = argv[5];
   if(argc>=7) {
      printf ("argv %d, %s\n", argc, argv[6]);
      changed_file = argv[6];
   }


   /* program call */

   Fimage disp = fimageread(disp_file);
   Fimage corr = fimageread(corr_file);
   nx =disp->ncol;
   ny =disp->nrow;
   nch=disp->nch;

   Fimage outdisp = new_fimage3(NULL,nx,ny,1);
   Fimage outcorr = new_fimage3(NULL,nx,ny,1);
   Fimage mask    = new_fimage3(NULL,nx,ny,1);

   /* read and merge the mask images */
   for (int j=0; j<nx*ny; j++) mask->gray[j]=255;
   for (int i=7; i<argc; i++) 
   {
      Fimage m = fimageread(argv[i]);
      printf("Reading mask: %s (only ch. 1 of %d)\n", argv[i], m->nch);
      for (int j=0; j<nx*ny; j++) 
      {
         if(m->gray[j*m->nch]==0) mask->gray[j]=0;
      }
      del_fimage(m);
   }

   minfilter(disp,corr,outdisp,outcorr,w,mask);

   /* computes a mask where the minfilter changed the value of the disparity*/ 
   /* TODO: maybe this is not the best place to compute this */
   if (changed_file){
      Fimage mask = new_fimage3(NULL,nx,ny,1);
      Fimage change_mask = new_fimage3(NULL,nx,ny,1);
      for (int j=0; j<nx*ny; j++) change_mask->gray[j]=255;
      for (int j=0; j<nx*ny; j++) if( fabs(disp->gray[j*nch] - outdisp->gray[j]) > MASK_THRES()) change_mask->gray[j]=0;
      fimagewrite (changed_file, change_mask);
      del_fimage(change_mask);
   }

   fimagewrite (outdisp_file, outdisp);
   fimagewrite (outcorr_file, outcorr);

   /* free memory (the program ends here) */

   return 0;
}

#endif
