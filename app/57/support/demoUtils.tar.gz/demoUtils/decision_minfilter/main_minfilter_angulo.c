#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "iio.h"
#include "fimage.h"
#include "smartparameter.h"

SMART_PARAMETER(MASK_THRES,1)


Fimage fimageread(char* name)
{
   int nx,ny,nc;
   float *disp = iio_read_image_float_vec(name, &nx, &ny, &nc);
   return new_fimage3(disp, nx,ny,nc);
}

void fimagewrite(char* name, Fimage i)
{
   iio_save_image_float_vec(name, i->gray, i->ncol, i->nrow, 1);
}

//TODO : Update help message
void help(char **argv)
{
   fprintf(stderr,"Missing parameters:\n");
   fprintf(stderr,"Usage: %s <window_size> <disparity> <cost> <argmin> <output_disparity> <output_cost> <output_argmin> [change_mask] [mask1] [mask2] ...\n",argv[0]);
   fprintf(stderr,"change_mask = |MF(disp) - disp| > MASK_THRES\nUse the enviroment variable MASK_THRES=thres to modify threshold (default=1).  ");
   exit(1);
}

void minfilter_angulo(Fimage in_disp, Fimage in_cost, Fimage in_argmin,
					Fimage out_disp, Fimage out_cost, Fimage out_argmin,
					int w, Fimage mask);

int main (int argc, char **argv)
{

   /* parameter parsing*/
   int w = 7;
   int nx,ny,nch;
   char *disp_file    = NULL;
   char *cost_file    = NULL;
   char *argmin_file    = NULL;
   char *outdisp_file = NULL;
   char *outcost_file = NULL;
   char *outargmin_file = NULL;
   char *changed_file = NULL;



   /* ppatameter parsing - parameters*/
   if(argc<8)
   {
        // TODO : correct help !!
      fprintf (stderr, "too few parameters\n");
      help(argv);
      return EXIT_FAILURE;
   }

   w            = atoi (argv[1]);
   disp_file    = argv[2];
   cost_file    = argv[3];
   argmin_file = argv[4];
   outdisp_file = argv[5];
   outcost_file = argv[6];
   outargmin_file = argv[7];
   if(argc>=9)
   {
      printf ("argv %d, %s\n", argc, argv[8]);
      changed_file = argv[8];
   }


   /* program call */

   Fimage disp = fimageread(disp_file);
   Fimage cost = fimageread(cost_file);
   Fimage argmin = fimageread(argmin_file);
   nx=disp->ncol;
   ny=disp->nrow;
   nch=disp->nch;

   Fimage outdisp = new_fimage3(NULL,nx,ny,1);
   Fimage outcost = new_fimage3(NULL,nx,ny,1);
   Fimage outargmin = new_fimage3(NULL,nx,ny,2);
   Fimage mask    = new_fimage3(NULL,nx,ny,1);

   /* read and merge the mask images */
   for (int j=0; j<nx*ny; j++) mask->gray[j]=255;
   for (int i=8; i<argc; i++) {
      Fimage m = fimageread(argv[i]);
      printf("Reading mask: %s (only ch. 1 of %d)\n", argv[i], m->nch);
      for (int j=0; j<nx*ny; j++) {
         if(m->gray[j*m->nch]==0) mask->gray[j]=0;
      }
      del_fimage(m);
   }

   minfilter_angulo(disp,cost,argmin,outdisp,outcost,outargmin,w,mask);

   /* computes a mask where the minfilter changed the value of the disparity*/
   /* TODO: maybe this is not the best place to compute this */
   if (changed_file){
      Fimage mask = new_fimage3(NULL,nx,ny,1);
      Fimage change_mask = clone_fimage(disp);
      for (int j=0; j<nx*ny; j++) change_mask->gray[j]=255;
      for (int j=0; j<nx*ny; j++) if( fabs(disp->gray[j*nch] - outdisp->gray[j]) > MASK_THRES()) change_mask->gray[j]=0;
      fimagewrite (changed_file, change_mask);
      del_fimage(change_mask);
   }

   fimagewrite (outdisp_file, outdisp);
   fimagewrite (outcost_file, outcost);
   iio_save_image_float_vec(outargmin_file, outargmin->gray, outargmin->ncol, outargmin->nrow, 2);

   /* free memory (the program ends here) */

   return EXIT_SUCCESS;
}
