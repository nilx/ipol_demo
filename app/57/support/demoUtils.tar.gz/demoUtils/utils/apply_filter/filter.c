#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "iio.h"

/*
This function applies a filter to a disparity map. The values of the input
disparity map disp are copied in the output file, putting to NAN the pixels
where the filter value is 0.
The input disparity map and filter have the same dimensions w (width) and h (height).
The filter is a monochannel image, the disparity map may have several channels (input parameter pd)
but in the output will be stored only the first channel.
*/
void apply_filter(float *disp, float *filt, float *out, int w, int h, int pd)
{
	int pix = 0;
	for (int row=0; row<h; row++)
		for (int col=0; col<w; col++)
		{
			pix = row*w+col;
			if (filt[pix] == 0)
				out[pix] = NAN;
			else
				out[pix] = disp[pix*pd];
		}
}


int main(int c, char *v[])
{
    if (c < 4)
    {
        printf("Missing arguments\n");
        printf("Usage: %s <disparity> <filter> <disparity_filtered>\n", v[0]);
	return EXIT_FAILURE;
    }

    // Parameters loading
    char *file_disp = v[1];
    char *file_filt = v[2];
    char *file_out = v[3];

    // Input loading
    int w1, h1, pd;
    int w2, h2;
    float *disp = iio_read_image_float_vec(file_disp, &w1, &h1, &pd);
	float *filt = iio_read_image_float(file_filt, &w2, &h2);

	// Sizes checking
	if ((w1 != w2) | (h1 != h2))
	{
		printf("Input files must have the same dimensions\n");
		return EXIT_FAILURE;
	}

	if ((pd > 1))
		printf("%s : the disparity is multi-channel: only the first channel is being considered\n",v[0]);

	int w = w1;
	int h = h1;

    // Memory allocations
    float *output = malloc(w*h*sizeof(float));

    // Image processing
    apply_filter(disp, filt, output, w, h, pd);
    iio_save_image_float_vec(file_out, output, w, h, 1);

    // Free memory
    free(disp);
    free(filt);
    free(output);

    return EXIT_SUCCESS;
}
