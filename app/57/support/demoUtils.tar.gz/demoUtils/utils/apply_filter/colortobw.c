#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "iio.h"

/*
This function converts a color image to a single channel one
*/
float* colortobw(float *in, int w, int h, int pd)
{
   float *out = malloc(w*h*sizeof(float));
	for (int row=0; row<h; row++)
		for (int col=0; col<w; col++)
		{
			int pix = row*w+col;
			out[pix] = 0;
			for (int t=0; t<pd; t++) 
				out[pix] += in[pix*pd + t];
         out[pix] /= pd;
		}
   return out;
}


int main(int c, char *v[])
{
    if (c < 3)
    {
        printf("Missing arguments\n");
        printf("Usage: %s <input> <bw_output_image> \n", v[0]);
	return EXIT_FAILURE;
    }

    // Parameters loading
    char *file_in  = v[1];
    char *file_out = v[2];

    // Input loading
    int w, h, pd;
    float *in = iio_read_image_float_vec(file_in, &w, &h, &pd);

    // Image processing
    float *output = colortobw(in , w, h, pd);
    iio_save_image_float_vec(file_out, output, w, h, 1);

    // Free memory
    free(in);
    free(output);

    return EXIT_SUCCESS;
}
