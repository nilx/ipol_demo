#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "iio.h"

/*
This function transforms the provided disparity map to allow better visualization.
The input disparity map is supposed to be filtered, and stored in a monochannel image. The
discarded pixels have value NAN. The output is the same disparity map stored in a
three-channels image, where the pixels that were NAN are transformed in cyan pixels.
The input disparity map has dimensions w (width) and h (height). The output is written at the address out.
*/
void render_filtered_map(float *disp, float *out, int w, int h)
{
	// Initialization of min and max : in order to find min and max of the
	// disp map, we need to have initial values for them, that are not nan.
	// Here we take the fist value that is not nan
	int pix=0;
	float init_value=0;
	bool pixels_are_nan = true;

	while (pixels_are_nan && (pix<w*h))
	{
		if (!(isnan(disp[pix])))
		{
			init_value = disp[pix];
			pixels_are_nan = false;
		}
		pix++;
	}
	float min=init_value;
    float max=init_value;

	// Find min and max in the disp map
	for (pix=0; pix<w*h; pix++)
    {
        if (!(isnan(disp[pix])))
        {
            if (disp[pix] < min)
                min = disp[pix];
            if (disp[pix] > max)
                max = disp[pix];
        }
    }

	// Render the disparity map
	for (pix=0; pix<w*h; pix++)
    {
        if (isnan(disp[pix]))
        {
            // Put cyan in the pixel
            out[pix*3+0] = min;
            out[pix*3+1] = max;
            out[pix*3+2] = max;
        }
        else
        {
            // Copy the disp value in the three channels
            out[pix*3+0] = disp[pix];
            out[pix*3+1] = disp[pix];
            out[pix*3+2] = disp[pix];
        }
    }
}


int main(int c, char *v[])
{
    if (c < 3)
    {
        printf("Missing arguments\n");
        printf("Usage: %s <disparity> <disparity_rendered>\n", v[0]);
	return EXIT_FAILURE;
    }

    // Parameters loading
    char *file_disp = v[1];
    char *file_out = v[2];

    // Input loading
    int w, h, pd;
    float *disp = iio_read_image_float_vec(file_disp, &w, &h, &pd);

	// Input checking
	if ((pd != 1))
	{
		printf("%s: The input disparity map has to be monochannel\n", v[0]);
		return EXIT_FAILURE;
	}

    // Memory allocations
    float *output = malloc(3*w*h*sizeof(float));

    // Image processing
    render_filtered_map(disp, output, w, h);
    iio_save_image_float_vec(file_out, output, w, h, 3);

    // Free memory
    free(disp);
    free(output);

    return EXIT_SUCCESS;
}
