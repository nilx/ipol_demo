#include <stdlib.h>
#include <stdio.h>
#include "iio.h"

/*
Input : N filters (images with pixels values zero or positive)
Output : intersection of these filters (i.e. pointwise multiplication)
This output image is written at the address filt_out
*/
void intersect(float **filt, int N,	float *filt_out, int w, int h)
{
	// Initialization
	for (int pix=0; pix<w*h; pix++)
		filt_out[pix] = 1;

	float *filt_img = NULL;

	// Compute the product
	for (int pix=0; pix<w*h; pix++)
	{
		for (int i=0; i<N; i++)
		{
			filt_img = filt[i];
			filt_out[pix] *= filt_img[pix];
		}
	}
}


int main(int c, char *v[])
{
    if (c < 3)
    {
        printf("Missing arguments\n");
        printf("Usage: %s <filt1> <filt2>... <filt_out>\n", v[0]);
	return EXIT_FAILURE;
    }

    // Parameters loading
    int N = c-2; // Number of filters
    float **filt = malloc(N*sizeof(float*));
    int w, h, pd;

    for (int i=0; i<N; i++)
		filt[i] = iio_read_image_float(v[i+1], &w, &h);

	char *file_filt_out = v[c-1];

    // Memory allocations
    float *filt_out = malloc(w*h*sizeof(float));

    // Image processing
    intersect(filt, N, filt_out, w, h);
    iio_save_image_float_vec(file_filt_out, filt_out, w, h, 1);

    // Free memory
    for (int i=0; i<N; i++)
		free(filt[i]);

    free(filt);
    free(filt_out);

    return EXIT_SUCCESS;
}
