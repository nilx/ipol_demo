#include <stdlib.h>
#include <stdio.h>
#include "iio.h"

/*
This function counts the number of pixels that are validated by the provided
filter (stored at address filt) of dimensions w (width) and h (height).
A pixel 'pix' is validated by the filter 'filt' is filt[pix] > 0, and discarded
if not.
*/
int count_valid_pixels(float *filt, int w, int h)
{
	int result = 0;
	for (int row=0; row<h; row++)
		for (int col=0; col<w; col++)
		{
			if (filt[row*w+col] > 0)
				result++;
		}
	return result;
}


int main(int c, char *v[])
{
    if (c < 2)
    {
        printf("Missing arguments\n");
        printf("Usage: %s <filter>\n", v[0]);
	return EXIT_FAILURE;
    }

    // Parameters loading
    char *file_filt = v[1];

    // Input loading
    int w, h;
	float *filt = iio_read_image_float(file_filt, &w, &h);

    // Image processing
    printf("Number of valid pixels : %d\n", count_valid_pixels(filt, w, h));

    // Free memory
    free(filt);

    return EXIT_SUCCESS;
}
