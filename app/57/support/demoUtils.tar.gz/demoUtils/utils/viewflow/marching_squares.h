float (*marching_squares_whole_image_float(int *n,
			float *image, int w, int h, float t))[2][2];

//float (*marching_squares_whole_image_uint8(int *n,
//			uint8_t *image, int w, int h, float t))[2][2];

//float (*marching_squares_whole_image(int *n,
//			float *image, int w, int h, float t))[2];
//
//int marching_squares_single_cell(int (*segments)[2],
//		float a, float b, float c, float d,
//		float t);

//int marching_squares_from_point(float (*curve)[2],
//		float **image, int w, int h, float x, float y);
//int marching_squares_from_edgel_point(float (*curve)[2],
//		float **image, int w, int h, int edgel_id, float alpha);
//
//void marching_squares_step(
