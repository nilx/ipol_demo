#include <iostream>
#include <cmath>
#include <stdlib.h>
//#include <unistd.h>
#include <time.h>
#include "mt19937ar.h"


#ifndef M_PI
#define M_PI 3.14159265358979323846264338327
#endif

void fiAddNoise(float *u, float *v, float std, long int randinit, unsigned size)
{
	mt_init_genrand((unsigned long int) time (NULL) + 
         (long int)time(NULL) + (long int)clock() +
         (unsigned long int) randinit);

    for (unsigned i = 0; i < size; i++)
    {
        double a = mt_genrand_res53();
        double b = mt_genrand_res53();
        double z = (double)(std) * sqrt(-2.0 * log(a)) * cos(2.0 * M_PI * b);

        v[i] =  u[i] + (float) z;
    }
}




/************************************************************
 *   MAIN FUNCTION
 ***********************************************************/

#ifndef DONT_USE_MAIN

extern "C" {
#include "iio.h"
}

using namespace std;

int main(int argc, char **argv)
{
    //! Check if there is the right call for the algorithm
	if (argc < 3)
	{
		cout << "Usage: " << argv[0] << " input_image noise_sigma output_image" << endl;
		return EXIT_FAILURE;
	}

	//! read input image
	cout << "Read input image...";
	int height, width, chnls;
	float *img = NULL;
	img = iio_read_image_float_vec(argv[1], &width, &height, &chnls);
	if (!img)
	{
		cout << "error :: " << argv[1] << " not found  or not a correct png image" << endl;
		return EXIT_FAILURE;
	}
	cout << "done." << endl;


	//! Variables initialization
	float    fSigma    = atof(argv[2]);
   unsigned wh        = (unsigned) width * height;
   unsigned whc       = (unsigned) wh * chnls;


	//! Add noise
	cout << "Add noise [sigma = " << fSigma << "] ...";
	float *img_noisy    = (float *) malloc(whc * sizeof(float));

	for (unsigned c = 0; c < chnls; c++)
		fiAddNoise(&img[c * wh], &img_noisy[c * wh], fSigma, c, wh);
    cout << "done." << endl;

	//! save noisy, denoised and differences images
	cout << "Save images...";
	iio_save_image_float_vec(argv[3], img_noisy, width, height, chnls);
//		cout << "... failed to save png image " << argv[3] << endl;

	//! Free Memory
	free(img_noisy   );

	return EXIT_SUCCESS;
}

#endif
