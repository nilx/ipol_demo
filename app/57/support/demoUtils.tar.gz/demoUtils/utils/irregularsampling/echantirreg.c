/*--------------------------- MegaWave2 module --------------------------*/
/* mwcommand
name = {echantirreg};
author = {"Julien Caron"};
version = {"1.2"};
function = {" perturbe une image HR (filtrée) et rend une image interpolée par splines cubiques "};
usage = { 
          'n':[n=2.0] -> p_n [1.0,10.0] "facteur d'échelle entre l'image d'entrée et l'image de sortie (défaut = 2.0) ", 
          'p'->position "avec cette option les fichiers epsx et epsy sont considérés commme des positions et non plus des décalages",  
          imageME->A   "Input regularly sampled fimage",
          epsx->epsx   "Input x fimage",
	       epsy->epsy   "Input y fimage",
          result<-C    "Output irregularly sampled fimage"
};
*/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include "iio.h"
#include "fimage.h"

#define MAX(a,b) (a>b?a:b)
#define MIN(a,b) (a<b?a:b)
#define pow3(a) (a*a*a)
#define sqr(a) a*a


/* ---------------- */
/*  Sous fonctions  */
/* ---------------- */

float spline3tens( float x , float y )   
   /* calcule la spline de degré 3 en (x,y)  */
{
   float x2 = fabs(x) , y2 = fabs(y) ; 
   float s = 0.0 , t = 0.0 ;
   float z0 ;


   if ( ( x2 < 2.0 ) && ( y2 < 2.0 ) )  {

      z0 = 2.0 - x2 ;
      s = pow3( z0 ) / 6.0 ;     
      if ( x2 < 1.0 )   {
         z0-- ;
         s -= pow3( z0 ) / 1.5 ;
      }

      z0 = 2.0 - y2 ;
      t = pow3( z0 ) / 6.0 ;
      if ( y2 < 1.0 )   { 
         z0-- ;
         t -= pow3 ( z0 ) / 1.5 ;
      }
      s *= t ;
   }

   return s ;

}

/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */

void spline3inverse( float *F , float *X , int m , int n , int L ) 
   /* X recoit spline3inverse(F) : la méthode est bonne loin du bord , pour qq ch de très précis voir [Unser] */
{
   float r = 2.0 - sqrt(3.0) ;

   float *Y , *Z ;
   int i , j , D = (m-1)*n , n2 = 2*n;

   if  ( ( ( Y = malloc(L*sizeof(float)) ) == NULL ) || ( ( Z = malloc(L*sizeof(float)) ) == NULL ) ) {
      fprintf(stderr,"pas assez de place pour la fonction spline3inverse \n ") ;
      exit(1);
   }


   /* déconvolution en x */

   /* descente */ 
   for (i=0 ; i<m ; i++ )   {
      Y[i*n] = 0.0 ;
      for (j=1 ; j<n ; j++ )   {
         Y[i*n+j] = F[i*n+j] - r * Y[i*n+j-1] ;
      }
   }

   /* remontée */
   for (i=0 ; i<m ; i++ )   {
      Z[(i+1)*n-1] = 0.0 ;
      for (j=n-2 ; j>=0 ; j-- )   {
         Z[i*n+j] = r * ( 6.0 * Y[i*n+j] - Z[i*n+j+1] ) ;
      }
   }

   /* déconvolution en y */

   /* descente */
   for (j=0 ; j<n ; j++)   {
      Y[j] = 0.0 ;
      for (i=1 ; i<m ; i++)   {
         Y[i*n+j] = Z[i*n+j] - r * Y[(i-1)*n+j] ;
      }
   }

   /* remontée */
   for (j=0 ; j<n ; j++)   {
      X[D+j] = 0.0 ;
      for (i=m-2 ; i>=0 ; i--)  {
         X[i*n+j] = r * ( 6.0 * Y[i*n+j] - X[(i+1)*n+j] ) ;
      }
   }

   free(Y) ;
   free(Z) ;

}

/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */

void echantirreg( Fimage A , Fimage epsx , Fimage epsy , Fimage C , float p_n , int position )
{

   /* Initialisation */

   int m = A->nrow ;
   int n = A->ncol ;

   int m2 = epsx->nrow ;
   int n2 = epsx->ncol ;

   int m3 = epsy->nrow ;
   int n3 = epsy->ncol ;

   if ( ( m2 != m3 ) || (n2 != n3) )  {
      fprintf(stderr,"les images epsx et epsy doivent avoir les mêmes dimensions \n") ;
      exit(1);
   }

   int L = m * n , L2 = m2 * n2 ;

   float *X , *A_ptr = A->gray ;

   if ( ( X = malloc(L*sizeof(float)) ) == NULL ) {
      fprintf(stderr,"Pas assez de place mémoire pour le vecteur X !\n") ;
      exit(1);
   }



   /*              programme             */

   /* X recoit la transformée spline3 inverse de A */
   spline3inverse( A_ptr , X , m , n , L ) ;             


   float *epsx_ptr = epsx->gray , *epsy_ptr = epsy->gray ;

   float *C_ptr = C->gray , *X_ptr ;

   float m2f = (float)m2 , n2f = (float)n2 , x , y , kf , lf , XDf , XFf , YDf , YFf , i , j ;

   int k , l , XD , XF , YD , YF , n4 = n-4 ;


   for ( i = 0.0 ; i < m2f ; i++ )  for ( j = 0.0 ; j < n2f ; j++ )  {

      if ( p_n != 1.0 )   {  
         if ( position )  {
            y = p_n * (*epsy_ptr) ;
            x = p_n * (*epsx_ptr) ;
         }
         else {
            y = p_n * ( i + *epsy_ptr ) ;
            x = p_n * ( j + *epsx_ptr ) ;
         }
      }
      else   {
         if ( position )  {
            y = *epsy_ptr ;
            x = *epsx_ptr ;
         }
         else {
            y = i + *epsy_ptr ;
            x = j + *epsx_ptr ;
         }
      } 

      *C_ptr = 0.0 ; 

      if ( ( x < 1.0 ) || ( x > n-2 ) || ( y < 1.0 ) || ( y > m-2 ) )  {
         XD = MAX( 0 , (int)( x - 1.0 ) ) ;
         XF = MIN( n-1 , (int)( x + 2.0 ) ) ;
         YD = MAX( 0 , (int)( y - 1.0 ) ) ;
         YF = MIN( m-1 , (int)( y + 2.0 ) ) ;
         XDf = (float)XD ;
         XFf = (float)XF ;
         YDf = (float)YD ;
         YFf = (float)YF ;   
         for ( k = YD , kf = YDf ; k <= YF , kf <= YFf ; k++ , kf++ )   
            for ( l = XD , lf = XDf ; l<= XF , lf <= XFf ; l++ , lf++ )    
               *C_ptr += X[ k * n + l ] * spline3tens( x - lf , y - kf ) ;
      }

      else {
         XD = (int)( x - 1.0 ) ;
         YD = (int)( y - 1.0 ) ;
         XDf = (float)XD ;
         YDf = (float)YD ; 
         X_ptr = X + YD*n + XD ;
         for ( k = 0 , kf = YDf ; k < 4 ; k++ , kf++ )  { 
            for ( l = 0 , lf = XDf ; l < 4 ; l++ , lf++ )   {  
               *C_ptr += *X_ptr * spline3tens( x - lf , y - kf ) ;
               X_ptr++ ;
            }
            X_ptr += n4 ;
         }  
      }

      C_ptr++ ;
      epsx_ptr++ ;
      epsy_ptr++ ;
   }

}


void echantirreg_color(Fimage A ,Fimage epsx ,Fimage epsy ,Fimage C ,float p_n ,int position )
{
   int nc = A->ncol, nr =A->nrow, nch = A->nch;
   int N=nc*nr;

   Fimage ti = new_fimage3(NULL,nc,nr,1);
   Fimage to = new_fimage3(NULL,C->ncol,C->nrow,1);

   for (int c=0;c<nch;c++){
      for(int i=0;i<N;i++) ti->gray[i] = A->gray[i*nch+c];
      echantirreg(ti ,epsx ,epsy ,to ,p_n ,position ); 
      for(int i=0;i<C->ncol*C->nrow;i++) C->gray[i*nch+c] = to->gray[i];
   }
   del_fimage(ti);
   del_fimage(to);
}

Fimage fimageread(char* name) 
{
   int nx,ny,nc;
   float *fdisp = iio_read_image_float_vec(name, &nx, &ny, &nc);
   return new_fimage3(fdisp, nx,ny,nc);
}

void fimagewrite(char* name, Fimage i) 
{
   iio_save_image_float_vec(name, i->gray, i->ncol, i->nrow, i->nch);
}


int main(int argc, char **argv) 
{

   if(argc<5) 
   {
      printf("-------------------------------------------------------------------------------                        \n"); 
      printf("   \\\\           //   perturbe une image HR (filtrée) et rend une image                               \n");
      printf("    \\\\         //   interpolée par splines cubiques .                                                \n");
      printf("      echantirreg    Author(s) : Julien Caron.                                                         \n");
      printf("-------------------------------------------------------------------------------                        \n");
      printf("                                                                                                       \n");
      printf("usage : echantirreg imageME epsx epsy result [n] [p]                                                   \n");
      printf("                                                                                                       \n");
      printf("      imageME :   Input regularly sampled fimage                                                       \n");
      printf("      epsx :   Input x fimage                                                                          \n");
      printf("      epsy :   Input y fimage                                                                          \n");
      printf("      result : Output irregularly sampled fimage                                                       \n");
      printf("      n : (in [1.0,10.0], default 2.0) : scale factor between the input and output images              \n");
      printf("      p (default 0): by setting this option epsx and epsy are assumed to be positions not displacements\n");
      exit(1);
   }
   float p_n=2.0;
   int position=0;

   Fimage A    = fimageread(argv[1]);
   Fimage epsx = fimageread(argv[2]);
   Fimage epsy = fimageread(argv[3]);
   Fimage C    = new_fimage3(NULL,epsx->ncol, epsy->nrow, A->nch);

   if(argc>5) p_n = atof(argv[5]);
   if(argc>6) position = atoi(argv[6]);

   echantirreg_color(A ,epsx ,epsy ,C ,p_n ,position );

   fimagewrite (argv[4], C);
}

