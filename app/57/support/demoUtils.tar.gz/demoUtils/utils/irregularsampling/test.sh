../../bin/echantirreg testdata/r.png testdata/disp.tif testdata/zero.tif /tmp/u.png 1.0
display /tmp/u.png
