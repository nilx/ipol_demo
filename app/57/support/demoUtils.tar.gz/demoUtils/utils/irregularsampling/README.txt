echantirreg (adapted from Julien Caron's code)
----------------------------------------------

Given the image IN, and the displacement filed \eps=(epsx,epsy)

> echantirreg IN epsx epsy OUT n

Computes:

  OUT(x) = IN ( \eps ( n * x ) )

where the points x are in a regular grid.
By default n = 2, meaning that the input image is twice the size of the output.

To avoid artifacts in the output the input image must be smooth, 
and if possible twice the size of the output image.

