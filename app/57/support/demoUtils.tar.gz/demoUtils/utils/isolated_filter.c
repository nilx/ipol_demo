#include <assert.h>
#include <math.h>
#include "fimage.h"
#include "string.h"

#include "fimage_interp.h"


#define min(a,b) (((a)<(b))?(a):(b))
#define max(a,b) (((a)>(b))?(a):(b))




/*
 * Computes the weighted NCC :  (  sum k*[(u1 - mu_1)*(u2 - mu_2)/(s_1*s_2)  ) 
 * between the patch of the image 1 starting at pixel (ipx,ipy) 
 * and the patch of the image 2 starting at (iqx,iqy)
 * Where mu_1, s_1 and mu_2, s_2 are the averages and standard deviations of u1 and u2 respectively.
 * Assumes that sum (kernel) = 1
 * */
float distance_patch_weighted_ncc(Fimage u1, Fimage u2, int ipx, int ipy, int iqx, int iqy, Fimage kernel)
{
   int k_w = kernel->ncol;
   int k_h = kernel->nrow;
   int nc1 = u1->ncol;
   int nr1 = u1->nrow;
   int nch = u1->nch;
   int nc2 = u2->ncol;
   int nr2 = u2->nrow;

   // // TODO remove unnecessary tests
   // assert(u1->nch  == u2->nch );
   // if (!(ipx>=0 && ipy>=0 && ipx + k_w-1 < nc1 && ipy + k_h-1 < nr1 )) return nan("");
   if (!(iqx>=0 && iqy>=0 && iqx + k_w-1 < nc2 && iqy + k_h-1 < nr2 )) return nan("");

   double fDist = 0.0f;

   for (int cc=0; cc < nch; cc++) {
      // compute means
      double mean1=0;
      double mean2=0;

      const float *ptr1 = u1->gray + (ipy * nc1 + ipx)*nch + cc;
      const float *ptr2 = u2->gray + (iqy * nc2 + iqx)*nch + cc;
      const float *ptrk = kernel->gray;

      for (int yy = 0; yy < k_h; yy++)
      {
         for (int xx = 0; xx < k_w; xx++, ptr1+=nch, ptr2+=nch, ptrk++)
         {
            mean1 += *ptr1 * *ptrk;
            mean2 += *ptr2 * *ptrk;
         }
         ptr1 += (nc1 - k_w)*nch;
         ptr2 += (nc2 - k_w)*nch;
      }

      // compute NCC
      ptr1 = u1->gray + (ipy * nc1 + ipx)*nch + cc;
      ptr2 = u2->gray + (iqy * nc2 + iqx)*nch + cc;
      ptrk = kernel->gray;

      double var1=0;
      double var2=0;
      double cov=0;

      for (int yy = 0; yy < k_h; yy++)
      {
         for (int xx = 0; xx < k_w; xx++, ptr1+=nch, ptr2+=nch, ptrk++)
         {
            // compare pixel
            double k = sqrt(*ptrk);
            double dif1 = (*ptr1 - mean1) * k;
            double dif2 = (*ptr2 - mean2) * k;
            var1  += dif1*dif1;
            var2  += dif2*dif2;
            cov   += dif1*dif2;
         }
         ptr1 += (nc1 - k_w)*nch;
         ptr2 += (nc2 - k_w)*nch;
      }

      fDist += (1./nch)*min(max(cov / (sqrt(var1)*sqrt(var2)),0),1);
   }

   return (1.- fDist);
}


/*
 * Computes the weighted L2 distance - mean:  (  sum k*[u1 - mu_1 - u2 + mu_2]^2  ) 
 * between the patch of the image 1 starting at pixel (ipx,ipy) 
 * and the patch of the image 2 starting at (iqx,iqy)
 * Where mu_1 and mu_2 are the averages of u1 and u2 respectively.
 * Assumes that sum (kernel) = 1
 * */
float distance_patch_weighted_l2mean(Fimage u1, Fimage u2, int ipx, int ipy, int iqx, int iqy, Fimage kernel)
{
   int k_w = kernel->ncol;
   int k_h = kernel->nrow;
   int nc1 = u1->ncol;
   int nr1 = u1->nrow;
   int nch = u1->nch;
   int nc2 = u2->ncol;
   int nr2 = u2->nrow;

   // // TODO remove unnecessary tests
   // assert(u1->nch  == u2->nch );
   // if (!(ipx>=0 && ipy>=0 && ipx + k_w-1 < nc1 && ipy + k_h-1 < nr1 )) return nan("");
   if (!(iqx>=0 && iqy>=0 && iqx + k_w-1 < nc2 && iqy + k_h-1 < nr2 )) return nan("");

   // compute mean
   float mean[nch];

   const float *ptr1 = u1->gray + (ipy * nc1 + ipx)*nch;
   const float *ptr2 = u2->gray + (iqy * nc2 + iqx)*nch;
   const float *ptrk = kernel->gray;

   for (int cc=0; cc < nch; cc++) mean[cc] = 0;
   for (int yy = 0; yy < k_h; yy++)
   {
      for (int xx = 0; xx < k_w; xx++,ptrk++)
      {
         for (int cc=0; cc < nch; cc++,ptr1++,ptr2++)
         {
            mean[cc] += (*ptr1 - *ptr2)* *ptrk;
         }
      }
      ptr1 += (nc1 - k_w)*nch;
      ptr2 += (nc2 - k_w)*nch;
   }

   // compute SSD-mean
   float fDist = 0.0f;
   float dif = 0.0f;

   ptr1 = u1->gray + (ipy * nc1 + ipx)*nch;
   ptr2 = u2->gray + (iqy * nc2 + iqx)*nch;
   ptrk = kernel->gray;

   for (int yy = 0; yy < k_h; yy++)
   {
      for (int xx = 0; xx < k_w; xx++,ptrk++)
      {
         // compare pixel
         for (int cc=0; cc < nch; cc++,ptr1++,ptr2++)
         {
            dif = *ptr1 - *ptr2 - mean[cc];
            fDist += *ptrk * dif * dif / nch;
         }
      }
      ptr1 += (nc1 - k_w)*nch;
      ptr2 += (nc2 - k_w)*nch;
   }

   return fDist;
}


/*
 * Computes the weighted L1 distance - mean:  (  sum k*|u1 - mu_1 - u2 + mu_2|  ) 
 * between the patch of the image 1 starting at pixel (ipx,ipy) 
 * and the patch of the image 2 starting at (iqx,iqy)
 * Where mu_1 and mu_2 are the averages of u1 and u2 respectively.
 * Assumes that sum (kernel) = 1
 * */
float distance_patch_weighted_l1mean(Fimage u1, Fimage u2, int ipx, int ipy, int iqx, int iqy, Fimage kernel)
{
   int k_w = kernel->ncol;
   int k_h = kernel->nrow;
   int nc1 = u1->ncol;
   int nr1 = u1->nrow;
   int nch = u1->nch;
   int nc2 = u2->ncol;
   int nr2 = u2->nrow;

   // // TODO remove unnecessary tests
   // assert(u1->nch  == u2->nch );
   // if (!(ipx>=0 && ipy>=0 && ipx + k_w-1 < nc1 && ipy + k_h-1 < nr1 )) return nan("");
   if (!(iqx>=0 && iqy>=0 && iqx + k_w-1 < nc2 && iqy + k_h-1 < nr2 )) return nan("");

   // compute mean
   float mean[nch];

   const float *ptr1 = u1->gray + (ipy * nc1 + ipx)*nch;
   const float *ptr2 = u2->gray + (iqy * nc2 + iqx)*nch;
   const float *ptrk = kernel->gray;

   for (int cc=0; cc < nch; cc++) mean[cc] = 0;
   for (int yy = 0; yy < k_h; yy++)
   {
      for (int xx = 0; xx < k_w; xx++,ptrk++)
      {
         for (int cc=0; cc < nch; cc++,ptr1++,ptr2++)
         {
            mean[cc] += (*ptr1 - *ptr2)* *ptrk;
         }
      }
      ptr1 += (nc1 - k_w)*nch;
      ptr2 += (nc2 - k_w)*nch;
   }

   // compute SAD-mean
   float fDist = 0.0f;
   float dif = 0.0f;

   ptr1 = u1->gray + (ipy * nc1 + ipx)*nch;
   ptr2 = u2->gray + (iqy * nc2 + iqx)*nch;
   ptrk = kernel->gray;

   for (int yy = 0; yy < k_h; yy++)
   {
      for (int xx = 0; xx < k_w; xx++,ptrk++)
      {
         // compare pixel
         for (int cc=0; cc < nch; cc++,ptr1++,ptr2++)
         {
            dif = *ptr1 - *ptr2 - mean[cc];
            fDist += *ptrk * (dif>=0?dif:-dif) / nch;
         }
      }
      ptr1 += (nc1 - k_w)*nch;
      ptr2 += (nc2 - k_w)*nch;
   }

   return fDist;
}

/*
 * Computes the weighted L2 distance between the patch of the image 1 starting at pixel (ipx,ipy) 
 * and the patch of the image 2 starting at (iqx,iqy)
 * */
float distance_patch_weighted_l2(Fimage u1, Fimage u2, int ipx, int ipy, int iqx, int iqy, Fimage kernel)
{
   int k_w = kernel->ncol;
   int k_h = kernel->nrow;
   int nc1 = u1->ncol;
   int nr1 = u1->nrow;
   int nch = u1->nch;
   int nc2 = u2->ncol;
   int nr2 = u2->nrow;

   // // TODO remove unnecessary tests
   // assert(u1->nch  == u2->nch );
   // if (!(ipx>=0 && ipy>=0 && ipx + k_w-1 < nc1 && ipy + k_h-1 < nr1 )) return nan("");
   if (!(iqx>=0 && iqy>=0 && iqx + k_w-1 < nc2 && iqy + k_h-1 < nr2 )) return nan("");

   float fDist = 0.0f;
   float dif = 0.0f;

   const float *ptr1 = u1->gray + (ipy * nc1 + ipx)*nch;
   const float *ptr2 = u2->gray + (iqy * nc2 + iqx)*nch;
   const float *ptrk = kernel->gray;

   for (int yy = 0; yy < k_h; yy++)
   {
      for (int xx = 0; xx < k_w; xx++,ptrk++)
      {
         // compare pixel
         //for (int cc=0; cc < nch; cc++,ptr1++,ptr2++)
         //{
         //   dif = *ptr1 - *ptr2;
         //   fDist += *ptrk * dif * dif / nch;
         //}
         for (int cc=nch; cc--; )
         {
            dif = *ptr1++ - *ptr2++;
            fDist += *ptrk * dif * dif / nch;
         }
      }
      ptr1 += (nc1 - k_w)*nch;
      ptr2 += (nc2 - k_w)*nch;
   }

   return fDist;
}

/*
 * Computes the weighted L1 distance between the patch of the image 1 starting at pixel (ipx,ipy) 
 * and the patch of the image 2 starting at (iqx,iqy)
 * */
float distance_patch_weighted_l1(Fimage u1, Fimage u2, int ipx, int ipy, int iqx, int iqy, Fimage kernel)
{
   int k_w = kernel->ncol;
   int k_h = kernel->nrow;
   int nc1 = u1->ncol;
   int nr1 = u1->nrow;
   int nch = u1->nch;
   int nc2 = u2->ncol;
   int nr2 = u2->nrow;

   // // TODO remove unnecessary tests
   // assert(u1->nch  == u2->nch );
   // if (!(ipx>=0 && ipy>=0 && ipx + k_w-1 < nc1 && ipy + k_h-1 < nr1 )) return nan("");
   if (!(iqx>=0 && iqy>=0 && iqx + k_w-1 < nc2 && iqy + k_h-1 < nr2 )) return nan("");

   float fDist = 0.0f;
   float dif = 0.0f;

   const float *ptr1 = u1->gray + (ipy * nc1 + ipx)*nch;
   const float *ptr2 = u2->gray + (iqy * nc2 + iqx)*nch;
   const float *ptrk = kernel->gray;

   for (int yy = 0; yy < k_h; yy++)
   {
      for (int xx = 0; xx < k_w; xx++,ptrk++)
      {
         // compare pixel
         for (int cc=0; cc < nch; cc++,ptr1++,ptr2++)
         {
            dif = *ptr1 - *ptr2;
            fDist += *ptrk * (dif>=0?dif:-dif) / nch;
         }
      }
      ptr1 += (nc1 - k_w)*nch;
      ptr2 += (nc2 - k_w)*nch;
   }

   return fDist;
}


/*
 * Computes the weighted L0 distance between the patch of the image 1 starting at pixel (ipx,ipy) 
 * and the patch of the image 2 starting at (iqx,iqy)
 * UPDATE : instead of l0 better use l_{1/4}, it approximates l0 
 * but avoids the coice of the threshold..
 * */
float distance_patch_weighted_l0(Fimage u1, Fimage u2, int ipx, int ipy, int iqx, int iqy, Fimage kernel)
{
   int k_w = kernel->ncol;
   int k_h = kernel->nrow;
   int nc1 = u1->ncol;
   int nr1 = u1->nrow;
   int nch = u1->nch;
   int nc2 = u2->ncol;
   int nr2 = u2->nrow;

   // // TODO remove unnecessary tests
   // assert(u1->nch  == u2->nch );
   // if (!(ipx>=0 && ipy>=0 && ipx + k_w-1 < nc1 && ipy + k_h-1 < nr1 )) return nan("");
   if (!(iqx>=0 && iqy>=0 && iqx + k_w-1 < nc2 && iqy + k_h-1 < nr2 )) return nan("");

   float fDist = 0.0f;
   float dif = 0.0f;

   const float *ptr1 = u1->gray + (ipy * nc1 + ipx)*nch;
   const float *ptr2 = u2->gray + (iqy * nc2 + iqx)*nch;
   const float *ptrk = kernel->gray;

   for (int yy = 0; yy < k_h; yy++)
   {
      for (int xx = 0; xx < k_w; xx++,ptrk++)
      {
         // compare pixel
         for (int cc=0; cc < nch; cc++,ptr1++,ptr2++)
         {
            //dif = fabs(*ptr1 - *ptr2);
            //fDist += *ptrk * (dif>=1?1:0) / nch;
            fDist += powl( fabs(*ptr1 - *ptr2),0.125);
         }
      }
      ptr1 += (nc1 - k_w)*nch;
      ptr2 += (nc2 - k_w)*nch;
   }

   return fDist;
}



/*
 * Computes the weighted L2 distance between the patch of the image 1 centered at (ipx,ipy) 
 * and the patch of the image 2 centered at (iqx,iqy)
 * The size of the patch is recovered from the size of the kernel.
 * */
float distance_patch_weighted_l2_center(Fimage u1, Fimage u2, int ipx, int ipy, int iqx, int iqy, Fimage kernel)

{
   int hk_w = kernel->ncol/2;
   int hk_h = kernel->nrow/2;

   return distance_patch_weighted_l2(u1,u2,ipx-hk_w,ipy-hk_h,iqx-hk_w,iqy-hk_h,kernel);
}




/* Extract patch from spline array Zu. 
 * (x,y) is the upper left corner of the patch on the image u
 * x and y can be noninteger and in that case the extracted patch
 * correspond to interpolated values of u.
 * The size of the patch is the size of u_extracted.
 * THE PARAMETERS OF THE INTEPOLATION ord AND sub ARE HARDCODED, 
 * BUT MUST COINCIDE WITH THE PREFILTER THAT GENERATED Zu
 * >      Fimage Zu = prefilter_fouspl(u, 11, 2);
 * */
void extract_patch(Fimage Zu, Fimage u_extracted, float x, float y) {
   assert(u_extracted->nch = Zu->nch);
   int nc = u_extracted->ncol,  nr = u_extracted->nrow, nch = u_extracted->nch;

   for (int c=0;c<nch;c++) 
   {
      float *ptr_u = u_extracted->gray+c;
      for (int b=0;b<nr;b++) 
         for (int a=0;a<nc;a++,ptr_u+=nch) 
            *ptr_u = subpixel_value_fouspl( Zu, 3, 16, x +a, y +b, c);
   }
}




/*
 * Evaluates the distance between the images u1 and u2 for the disparity d.
 */
Fimage compute_distances(Fimage u1, Fimage u2, Fimage d, int w, char * method) 
{
   int nc=d->ncol, nr=d->nrow, nch=d->nch;
   int halfw = w/2;

   // prefilter u2 to be able to interpolate it
   Fimage Zu2 = prefilter_fouspl(u2, 3, 16);
   printf("prefilter done\n");
   // to evaluate the image u2 at subpixel locations use:
   // float subpixel_value_fouspl( Zu2, 11, 2, float x, float y, int c);
   //    or to extract a patch starting from the subpixel location 
   // extract_patch(Zu2, u_extracted_patch, x +dx, y);
   Fimage u2_extracted_patch = new_fimage3(NULL,w,w,u2->nch);

   // generate a flat window
   Fimage kernel = new_fimage3(NULL, w ,w ,1);
   for(int i=0;i<w*w  ;i++)
      kernel->gray[i] = 1.0/(w*w);

   // allocate the output
   Fimage out    = new_fimage3(NULL, nc,nr,nch);
   for(int i=0;i<nc*nr;i++)
      out->gray[i] = 0;


#define compute_dist_for_all_patch_centers(distance_method_x)                                           \
      for(int z=0;z< nch;z++) /*if the disparity map have more than one channel*/                       \
      {                                                                                                 \
         for(int y=0;y<=nr-w;y++)                                                                       \
         {                                                                                              \
            for(int x=0;x<=nc-w;x++)                                                                    \
            {                                                                                           \
               int patchcenter = x+halfw + y*nc+halfw*nc;                                               \
               float dx = d->gray[z+patchcenter*nch];                                                   \
               /*out->gray[z+patchcenter*nch] =  */                                                     \
               /*   distance_patch_weighted_ncc(u1, u2, x, y, x+(int)dx, y, kernel);  */                \
               if( !isnan(dx) )  { /* detect nan  */                                                    \
                  extract_patch(Zu2, u2_extracted_patch, x +dx, y);                                     \
                  out->gray[z+patchcenter*nch] =                                                        \
                     (distance_method_x)(u1, u2_extracted_patch, x, y, 0, 0, kernel);                   \
               } else {                                                                                 \
                  out->gray[z+patchcenter*nch] = nan("");                                               \
               }                                                                                        \
            }                                                                                           \
         }                                                                                              \
      }                                                                                                 \
                                                                                                        \

   // compute the patch distance for all the points in the disparity map d.
   // Uses the macro defined above
   if (strcmp (method,"NCC")==0)
      compute_dist_for_all_patch_centers(distance_patch_weighted_ncc)
   else if (strcmp (method,"SSD")==0)
      compute_dist_for_all_patch_centers(distance_patch_weighted_l2)
   else if (strcmp (method,"SAD")==0)
      compute_dist_for_all_patch_centers(distance_patch_weighted_l1)
   else if (strcmp (method,"S0D")==0)
      compute_dist_for_all_patch_centers(distance_patch_weighted_l0)
   else if (strcmp (method,"SSD-mean")==0)
      compute_dist_for_all_patch_centers(distance_patch_weighted_l2mean)
   else if (strcmp (method,"SAD-mean")==0)
      compute_dist_for_all_patch_centers(distance_patch_weighted_l1mean)
   else 
   {
      fprintf(stderr, "UNKNOWN METHOD %s\n", method); exit(-1);
   }

   // free
   del_fimage(kernel);
   del_fimage(u2_extracted_patch);
   del_fimage(Zu2);

   return(out);
}




/*************  MAIN  ****************/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "iio.h"

Fimage fimage_read(char* name) 
{
   int nx,ny,nc;
   float *fdisp = iio_read_image_float_vec(name, &nx, &ny, &nc);
   return new_fimage3(fdisp, nx,ny,nc);
}

void fimage_write(char* name, Fimage i) 
{
   iio_save_image_float_vec(name, i->gray, i->ncol, i->nrow, i->nch);
}


int main (int argc, char **argv)
{
   char *im1_file       = NULL;
   char *im2_file       = NULL;
   char *disp_file      = NULL;
   char *out_corr_file  = NULL;
   int w                = 9;
   char method[32]      = "SSD-mean"; 

   /* patameter parsing - parameters*/
   if(argc<6) 
   {
      fprintf (stderr, "too few parameters\n");
      fprintf(stderr,"Computes all the patch distances for a certain disparity map\n");
      fprintf(stderr,"usage: compute_distances im1 im2 disp distance window_side [method]\n");
      fprintf(stderr,"       method can be one of: SAD, SSD, SAD-mean, SSD-mean(default)\n\n");
      return 1;
   }

   im1_file      = argv[1];
   im2_file      = argv[2];
   disp_file     = argv[3];
   out_corr_file = argv[4];
   w = atoi(argv[5]);
   if (argc==7)
      strcpy(method,argv[6]);


   /* program call */

   Fimage im1  = fimage_read(im1_file);
   Fimage im2  = fimage_read(im2_file);
   Fimage disp = fimage_read(disp_file);

   Fimage out_corr = compute_distances(im1, im2, disp, w, method);

   fimage_write (out_corr_file, out_corr);

   /* free memory (the program ends here) */

   return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "fimage.h"


/* min-filter the input with correlation corr, and generates a new 
 * disparity map with correlation newcorr. 
 * The size of the window is given by w.
 * If mask!=NULL then only the nonzero pixels are considered by the filter.*/
void minfilter(Fimage in, Fimage corr, Fimage out, Fimage newcorr, int w, Fimage mask)
{
  int y,x,i,j;
  int N = in->ncol*in->nrow;
  int nc = in->ncol, nr =in->nrow;
  int nch = in->nch, nch2 = corr->nch;

  /* in case the window size is not odd, we must adapt the right limit.
   * This is because the correlation treats the even windows as if their center O
   * is displaced towards right:  xxxOxx */
  int wl=w/2;
  int wr=w/2;
  if(w%2==0) wr--;

  if(nch>1 || nch2>1) {
     fprintf(stderr, "minfilter: only considering the first channel of each input\n");
  }

  // TODO: out SHOULD BE SET TO -1000 because the output of minfilter may be incorrect at some points.
  for(i=0;i<nr*nc;i++) out->gray[i]     = in->gray[i*nch];
  for(i=0;i<nr*nc;i++) newcorr->gray[i] = corr->gray[i*nch2];

  for(y=wl;y<nr-wr;y++) 
     for(x=wl;x<nc-wr;x++) {
        float currcorr=100000000;
        int pos = x+y*nc;
        for(i=-wl;i<=wr;i++) 
           for(j=-wl;j<=wr;j++) {
              int posW = x+i + (y+j)*nc;
              if ( currcorr > corr->gray[posW*nch2] && mask && mask->gray[posW] ) {
                 currcorr = corr->gray[posW*nch2];
                 newcorr->gray[pos]=currcorr;
                 out->gray[pos] = in->gray[posW*nch];
              }
           }
     }

}

// old minfilter without mask
//void minfilter(Fimage in, Fimage best, Fimage out, Fimage newbest, int w)
//{
//  int y,x,i,j;
//  int N = in->ncol*in->nrow;
//  int nc = in->ncol, nr =in->nrow;
//
//  /* in case the window size is not odd, we must adapt the right limit.
//   * This is because the correlation treats the even windows as if their center O
//   * is displaced towards right:  xxxOxx */
//  int wl=w/2;
//  int wr=w/2;
//  if(w%2==0) wr--;
//
//  if(in->nch>1 || best->nch>1) abort();
//
//  for(i=0;i<nr*nc;i++) out->gray[i]     = in->gray[i];
//  for(i=0;i<nr*nc;i++) newbest->gray[i] = best->gray[i];
//
//  for(y=wl+1;y<nr-wr-1;y++) 
//     for(x=wl+1;x<nc-wr-1;x++) {
//        float currbest=100000000;
//        for(i=-wl;i<=wr;i++) 
//           for(j=-wl;j<=wr;j++) {
//              if (currbest > best->gray[x+i + (y+j)*nc]) {
//                 currbest = best->gray[x+i + (y+j)*nc];
//                 newbest->gray[x+y*nc]=currbest;
//                 out->gray[x+y*nc] = in->gray[x+i + (y+j)*nc];
//              }
//           }
//     }
//
//}






/* MAIN  */

#ifndef DONT_USE_MAIN

#include "iio.h"
#include "smartparameter.h"

SMART_PARAMETER(MASK_THRES,1)


Fimage fimageread(char* name) 
{
   int nx,ny,nc;
   float *disp = iio_read_image_float_vec(name, &nx, &ny, &nc);
   return new_fimage3(disp, nx,ny,nc);
}

void fimagewrite(char* name, Fimage i) 
{
   iio_save_image_float_vec(name, i->gray, i->ncol, i->nrow, i->nch);
}



int main (int argc, char **argv)
{
   int w = 7;
   int nx,ny,nch;
   char *disp_file    = NULL;
   char *corr_file    = NULL;
   char *outdisp_file = NULL;
   char *outcorr_file = NULL;
   char *changed_file = NULL;

   /* ppatameter parsing - parameters*/
   if(argc<6) 
   {
      fprintf(stderr,"too few parameters\n");
      fprintf(stderr,"Min filter\n");
      fprintf(stderr,"usage: minfilter window_size disparity correlation output_disparity output_correlation [change_mask] [mask1] [mask2] ...\n");
      fprintf(stderr,"       change_mask is |MF(disp) - disp| > MASK_THRES\n");
      fprintf(stderr,"       Use the enviroment variable MASK_THRES=thres to modify threshold (default=1).\n");
      return 1;
   }

   w            = atoi (argv[1]);
   disp_file    = argv[2];
   corr_file    = argv[3];
   outdisp_file = argv[4];
   outcorr_file = argv[5];
   if(argc>=7) {
      printf ("argv %d, %s\n", argc, argv[6]);
      changed_file = argv[6];
   }


   /* program call */

   Fimage disp = fimageread(disp_file);
   Fimage corr = fimageread(corr_file);
   nx =disp->ncol;
   ny =disp->nrow;
   nch=disp->nch;

   Fimage outdisp = new_fimage3(NULL,nx,ny,1);
   Fimage outcorr = new_fimage3(NULL,nx,ny,1);
   Fimage mask    = new_fimage3(NULL,nx,ny,1);

   /* read and merge the mask images */
   for (int j=0; j<nx*ny; j++) mask->gray[j]=255;
   for (int i=7; i<argc; i++) 
   {
      Fimage m = fimageread(argv[i]);
      printf("Reading mask: %s (only ch. 1 of %d)\n", argv[i], m->nch);
      for (int j=0; j<nx*ny; j++) 
      {
         if(m->gray[j*m->nch]==0) mask->gray[j]=0;
      }
      del_fimage(m);
   }

   minfilter(disp,corr,outdisp,outcorr,w,mask);

   /* computes a mask where the minfilter changed the value of the disparity*/ 
   /* TODO: maybe this is not the best place to compute this */
   if (changed_file){
      Fimage mask = new_fimage3(NULL,nx,ny,1);
      Fimage change_mask = new_fimage3(NULL,nx,ny,1);
      for (int j=0; j<nx*ny; j++) change_mask->gray[j]=255;
      for (int j=0; j<nx*ny; j++) if( fabs(disp->gray[j*nch] - outdisp->gray[j]) > MASK_THRES()) change_mask->gray[j]=0;
      fimagewrite (changed_file, change_mask);
      del_fimage(change_mask);
   }

   fimagewrite (outdisp_file, outdisp);
   fimagewrite (outcorr_file, outcorr);

   /* free memory (the program ends here) */

   return 0;
}

#endif
