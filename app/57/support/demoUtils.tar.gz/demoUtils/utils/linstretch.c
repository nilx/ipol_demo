/*--------------------------- Commande MegaWave -----------------------------*/
/* mwcommand
   name = {flinstretch};
   version = {"0.2"};
   author = {"Andr�s Almansa"};
   function = {"Linear contrast change with tail cropping"};
   usage = {            
    'c':c->c   "crop c% of the histogram tails (default c=2%)",
    'm':m->m   "map minimum input gray-level to m (default 0)",
    'M':M->M   "map maximum input gray-level to M (default 255)",
    'n':n->n   "map      c % input gray-level to n (default 255*p)",
    'N':N->N   "map (100-c)% input gray-level to N (default 255-n)",
    'p':p->p   "use p instead of      c % input gray-level",
    'P':P->P   "use P instead of (100-c)% input gray-level",
    in->in     "input Fimage",
    out<-out   "output Fimage"
   };
*/

#include <stdio.h>
#include <math.h>
#include "mw.h"


/* #define NULL (void*)0
*/

/*extern Fsignal fhisto();*/
extern Fsignal fhisto(Fimage in, Fsignal out, float *l,float *r, int *n, float *s,char *t, Fimage w);


float cchange(x,xmin,x1,x2,xmax,ymin,y1,y2,ymax)
	float x,xmin,x1,x2,xmax,ymin,y1,y2,ymax;
{
	float y;
	
	if (x1<=x)
		if (x<x2)
			/* x in [x1..x2] */
			y = (y1*(x2-x) + y2*(x-x1))/(x2-x1);
		else if (x<xmax)
			/* x in [x2..xmax] */
			y = (y2*(xmax-x) + ymax*(x-x2))/(xmax-x2);
		else
			y = ymax;
	else
		if (xmin<=x)
			/* x in [xmin..x1] */
			y = (ymin*(x1-x) + y1*(x-xmin))/(x1-xmin);
		else
			y = ymin;
	
	return y;
}

/*** NB: Calling this module with out=in is possible ***/

void flinstretch(in,out,c,m,M,n,N,p,P)
     Fimage in,out;
     float *c,*m,*M,*n,*N,*p,*P;
{
  Fsignal hist;
  float crop,sum,psum,a,b,*pin,*pout;
  float input_min, input_max, input_p, input_P;
  float output_min,output_max, output_p, output_P;
  int   i,*ncells;
  
  if (M)
  	output_max=*M;
  else
	output_max=255.0;

  if (m)
  	output_min=*m;
  else
	output_min=0.0;

  if (c)
  	crop=*c;
  else
	crop=2.0;
  
  if (N)
  	output_P=*N;
  else
	output_P=output_max-(output_max-output_min)*crop/100.0;

  if (n)
  	output_p=*n;
  else
	output_p=output_min+(output_max-output_min)*crop/100.0;
	

  out = mw_change_fimage(out,in->nrow,in->ncol);
  if (!out) mwerror(FATAL,1,"Not enough memory.");

	ncells = (int*) malloc (sizeof(int));
  *ncells=1000;
  hist = fhisto(in,NULL,NULL,NULL,ncells,NULL,NULL,NULL);
  input_min = ((float) 0)*(hist->scale)+(hist->shift);
  input_max = ((float) hist->size)*(hist->scale)+(hist->shift);
      
  if (p)
  	input_p = *p;
  else	{
  	/* Crop lower tail at input_p = c% */
	for (sum=0.0,i=0;i<hist->size;i++)
		sum += hist->values[i];
	for (psum=0.0,i=0;psum<crop*sum/100.0;i++)
		psum += hist->values[i];
	input_p = ((float) i)*(hist->scale)+(hist->shift);
	fprintf(stderr,"%3.1f %% at p = %f\n",crop,input_p);
	}
  if (P)
  	input_P = *P;
  else  {
  	/* Crop upper tail at input_P = (100-c)% */
	for (sum=0.0,i=0;i<hist->size;i++)
		sum += hist->values[i];
	for (psum=0.0,i=0;psum<(100.0-crop)*sum/100.0;i++)
		psum += hist->values[i];
	input_P = ((float) i)*(hist->scale)+(hist->shift);
	fprintf(stderr,"%3.1f %% at P = %f\n",100-crop,input_P);
  }

  
/*  
  a = (max-min)/(gmax-gmin);
  b = max - a * gmax;
  */
  fprintf(stderr," input_min = %f,  input_p = %f,  input_P = %f,  input_max = %f\n",      input_min, input_p, input_P, input_max);
  fprintf(stderr,"output_min = %f, output_p = %f, output_P = %f, output_max = %f\n", output_min,output_p,output_P,output_max);

  
  for (i=in->nrow*in->ncol,pin=in->gray,pout=out->gray; i-- ; pin++,pout++) 
    *pout = cchange((*pin),
    	input_min, input_p, input_P, input_max,\
    	output_min,output_p,output_P,output_max);
}
/*--------------------------- MegaWave2 Module -----------------------------*/
/* mwcommand
 name = {fhisto};
 version = {"1.5"};
 author = {"Lionel Moisan"};
 function = {"Compute the histogram of a Fimage"};
 usage = {
    'l':l->l    "left bound of sampling interval",
    'r':r->r    "right bound of sampling interval",
    'n':n->n    "number of cells (if no option specified: 100)",
    's':s->s    "size of each cell (alternate option)",
    't'->t      "truncate values outside interval",
    'w':w->w    "specify a weight Fimage",
    input->in   "input Fimage",
    output<-out "output Fsignal"
};
*/
/*----------------------------------------------------------------------
 v1.2: more possible combinations of options, new -t option (L.Moisan)
 v1.3: default num = (max-min)/size (L.Moisan)
 v1.4: fixed -t option (P.Monasse)
 v1.5: added -w option (L.Moisan)
----------------------------------------------------------------------*/

#include <stdio.h>
#include <math.h>
#include "mw3.h"
#include "mw3-modules.h"

#define DEFAULT_NUMBER_OF_CELLS 100

Fsignal fhisto(Fimage in, Fsignal out, float *l, float *r, int *n, float *s,
               char *t, Fimage w)
{
    float min, max, size = 0.0, v;
    int num, i, cell;

    /* compute min and max */
    min = max = in->gray[0];
    for (i = in->nrow * in->ncol; i--;)
    {
        v = in->gray[i];
        if (v < min)
            min = v;
        if (v > max)
            max = v;
    }

    /* default */
    if (l)
        min = *l;
    if (r)
        max = *r;
    if (n)
        num = *n;
    else
    {
        if (s)
        {
            size = *s;
            num = (int) (0.5 + (max - min) / size);
            if (num <= 0)
                num = 1;
        }
        else
            num = DEFAULT_NUMBER_OF_CELLS;
    }
    if (!s)
        size = (max - min) / (float) num;

    switch ((l ? 1 : 0) + (r ? 1 : 0) + (n ? 1 : 0) + (s ? 1 : 0))
    {

    case 0:
        break;

    case 1:
        if (s)
        {
            min = size * floor((double) (min / size));
            num = 1 + floor((double) ((max - min) / size));
        }
        break;

    case 2:
        if (n && s)
            mwerror(USAGE, 1,
                    "You cannot use only -n and -s options together\n");
        break;

    case 3:
        if (!l)
            min = max - (float) num *size;
        if (!r)
            max = min + (float) num *size;
        if (!n)
        {
            size = (max - min) / (float) (num);
            if (size != *s)
                mwerror(WARNING, 0,
                        "cell size changed to match interval bounds\n");
        }
        break;

    default:
        mwerror(USAGE, 1,
                "You cannot use the 4 options -l -r -n and -s together\n");
    }

    /* prepare output */
    out = mw_change_fsignal(out, num);
    if (!out)
        mwerror(FATAL, 1, "Not enough memory\n");
    mw_clear_fsignal(out, 0.0);
    out->shift = min;
    out->scale = size;

    /* compute histogram */
    for (i = in->nrow * in->ncol; i--;)
    {
        cell = (in->gray[i] - min) / size;
        if (t)
        {
            if (cell < 0)
                cell = 0;
            if (cell >= num)
                cell = num - 1;
        }
        if (cell >= 0 && cell < num)
            out->values[cell] += (w ? w->gray[i] : 1.);
    }

    return (out);
}
