#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include "iio.h"


int main (int argc, char **argv)
{
   int fx=1, fy=1;

   /* ppatameter parsing - parameters*/
   if(argc<4) 
   {
      fprintf (stderr, "too few parameters %d\n",argc);
      fprintf (stderr, "zooms an image by an integer factor using pixel replication Nearest Neighbor.\n");
      fprintf (stderr, "   usage: %s in out factor_x [factor_y(default = factor_x)]\n",argv[0]);
      return 1;
   }

   fy = fx = atoi (argv[3]);
   if (argc>4) fy = atoi (argv[4]);

   int nc,nr,nch;
   float *in = iio_read_image_float_vec(argv[1], &nc, &nr, &nch);

   int onc=nc*fx;
   int onr=nr*fy;

   float *out = malloc(onc*onr*nch*sizeof*out);

   // set default
   for(int y=0;y<onc*onr*nch;y++) out[y]=0;

   // copy 
   for(int y=0;y<onr;y++)
   for(int x=0;x<onc;x++)
   for(int c=0;c<nch;c++)
   {
      int xx=x/fx;
      int yy=y/fy;
      out[c + ( x + y*onc )*nch] = in[c+(xx+yy*nc)*nch];
   }

   iio_save_image_float_vec(argv[2], out, onc, onr, nch);

   free(in);
   free(out);

   return 0;
}



