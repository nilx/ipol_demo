/*--------------------------- MegaWave2 module  -----------------------------*/
/* mwcommand
 name = {occlusions};
 author = {"Gabriele Facciolo"};
 version = {"1.0"};
 function = {"Computes the occlusions in a ground truth disparity map"};
 usage = {
   'i'->invert_flag  "the disparity map is inverted (higher values nearer points)",
   in->in          "input ideal disparity map",
   out<-out        "non correlable areas (occlusions)"
};
*/
/*--------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "iio.h"

typedef struct values {
	int preim[100];
   int cpreim;
	float f_value;
} VALUES , *VALUESPTR;




/* computhe the occlusions of a disparity map 
 * ------------------------------------------
 *
 * We assume that for each point of the disparity map we know the true depth.
 * Then we can compute the disparity d from the depth D, 
 * using d = f*b/(f+D)  (d: disparity, f: focal lenght, b: baseline, D: depth).
 * However no stereo algorithm will be able to produce this map without 
 * uncertainty, because of the self occlusions in the model.
 *
 * The objective of this program is to estimate the occlusions. 
 *
 * We are going to consider the left image as reference in a left-right pair,
 * and the depth map corresponding to the left image.
 * Therefore the signed disparityes of the nearby objects will be less than 
 * the the far objects ( they will be all negative in general ). 
 * This implies that the occlusions are always going to appear at the left 
 * of the objects.
 * 
 * 
 * The procedure to compute the occlusions is:
 * given a scanline d(x) of the disparity map, we define f(x) = x + d(x), 
 * and F_y = \{ x : f(x)  =y \}.
 * Then the non occluded portions of the scanline will be recovered as: 
 * Occ = \cup_y \max_x(F_y(x))
 * 
 * 
 * The occlusions algorith
 * -----------------------
 * F[] : is an array of lists, each position in the array represents an F_y, and pixel 
 * in the secondary scanline, the list will contain the index of the 
 * points in the reference scanline that correspond to the same poit ( fall nearby ) i.e. f(x) = y.
 * 
 * We process all discrete point x in the reference scanline from left to right.
 * For each one we compute x+f(x) and the two nearest integer positions 
 * y1=ceil(x+f(x)), y2=floor(x+f(x)). Then we add the index of x, in both lists F[y_1]  F[y_2].
 * 
 * 
 * Then the occlusion mask is constructed scanning each list in F[].
 * By default all the points are occluded.
 * Scanning backwards each list the first indexes (the last in the list) 
 * corredpond to the non occluded pixels, and are removed from the occluded mask.
 * In practice we mask as non occluded several pixels (not only the last one) 
 * as long as they are consecutive, because they may correspond to a sisible plane but slanted.
 * 
 *
 *
 * */
void occlusions_(int nx, int ny, float *in, float *occ) {
	int i,x,y,act,org;
	int numvalues;
	VALUESPTR f_values;

	/* Allocate the storage for one line */
	f_values = calloc((int) nx, sizeof(VALUES));

	/* Process each line */
	for(y=0;y<ny;y++){
		if( y%10 == 0) {printf("%d ", y); fflush(NULL); }

		/*********************************************************************** 
		 * Second compute the pseudoinverse over the line and the occluded zones 
		 ***********************************************************************/

		/* Initialize the level sets */
		for(x=0;x<nx;x++) {
						f_values[x].f_value = x ;
                  for (i=0; i< 100; i++) {
						   f_values[x].preim[i]=-1;
                  }
                  f_values[x].cpreim=0;
		}

		/* scan the pixels in the reference image */
		for(x=0;x<nx-1;x++){
			int low = x;

         float f_low = x + in[ x+ y*nx];
         int f = floor(f_low);
         int c = ceil(f_low);
         /* add to the corresponding lists the reference to x*/
         if(f_low >=0 && f_low <= nx-1) {
            f_values[f].preim[f_values[f].cpreim] = x;
            f_values[f].cpreim++;
            if(f!=c){
               f_values[c].preim[f_values[c].cpreim] = x;
               f_values[c].cpreim++;
            }

         }
		}
      /* by default all points are occlusions */
		for(x=0;x<nx;x++){
			occ[ x+ y*nx] = 1;
      }

#ifdef DEBUG
		for ( act=0; act< nx; act++ ) {
         for (i=f_values[act].cpreim-1;i>=0; i--) 
            printf("%d ", f_values[act].preim[i]);
         printf("\n");
      }
#endif

      /* determine which points are not occluded */
		for ( act=0; act< nx; act++ ) {
         int pprev=f_values[act].preim[f_values[act].cpreim-1];
         for (i=f_values[act].cpreim-1;i>=0; i--) 
            if( pprev -1 == f_values[act].preim[i] || pprev == f_values[act].preim[i]) {
               int pre = f_values[act].preim[i];   
               float fpre = pre + in[y*nx + pre];
               float fpprev = pprev + in[y*nx + pprev];

               if( fpre <= fpprev )
               {
              occ[ f_values[act].preim[i] + y*nx]=0;
              pprev =  f_values[act].preim[i];
               }
            }
            else
               i=-1;
      }

	} /* end for each line */
	free(f_values);
}






int main (int argc, char **argv)
{

   /* ppatameter parsing - parameters*/
   if(argc<3) 
   {
      fprintf (stderr, "too few parameters\n");
      fprintf (stderr, "compute the occlusions of the disparity map in\n");
      fprintf (stderr, "   usage: %s in out [-i] \n",argv[0]);
      return 1;
   }

   int nc,nr,nch,x,y;
   int invert_flag=0;
   float *in, *out;

   // only works with 1 image plane
   in = iio_read_image_float_split(argv[1], &nc, &nr, &nch);

   out = malloc(nc*nr*1*sizeof*out);

   if(argc>=4) invert_flag=1;


   /* handle right-left pairs  (default left-right) */
   if(invert_flag){
      float *in2 = malloc(nc*nr*1*sizeof*out);

      for(y=0;y<nr;y++) 
         for(x=0;x<nc;x++) {
            in2[y*nc +nc -1 - x] = - in[y*nc + x];
         }

      occlusions_(nc, nr, in2, out);

      for(y=0;y<nr;y++) 
         for(x=0;x<nc;x++) 
            in2[y*nc +nc -1 - x] = out[y*nc + x];

      for(y=0;y<nr*nc;y++) out[y] = in2[y];


      free(in2);
   }
   else
   {
      occlusions_(nc, nr, in, out);
   }

   /* scale values */
   for(y=0;y<nr*nc;y++) out[y] = out[y]*255;


   iio_save_image_float_split(argv[2], out, nc, nr, 1);


   free(in);
   free(out);

   return 0;
}


