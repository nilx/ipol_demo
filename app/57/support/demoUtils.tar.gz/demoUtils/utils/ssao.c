#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include "iio.h"


// dct type II symmetry at the boundary
   int p_sym(int nx, int ny, int x, int y) { 
      if(x < 0)
         x = -x-1;
      if(y < 0)
         y = -y-1;
      if(x >= nx)
         x = -x+2*nx-1;
      if(y >= ny)
         y = -y+2*ny-1;
      return x+nx*y;
   }

/*
 * SSAO
 *
 * \nabla_i : different discretizations of the gradient.
 *
 * % compute the normal to the surface d at the point x
 * % as the maximum gradient at that point
 *
 * p: current point (2d)
 * P= (p,eps(p)): 3d surface point associated to p
 * q: 8-neighbor point of p(2d)
 *
 * q = \argmax_{r \in Neigh(p)} ( |eps(r) - eps(p)|/||r-p|| )  
 *
 * % TODO: do something to recover the normal
 *
 * N(x) = (p-q)/|p-q|
 *
 *
 * % let V be an element of a set of 3d points (x,eps(x))
 * % neighbors of the current point p
 *
 * d = \| V - P\|
 * Occlusion(x) +=  max(0, N \cdot (V - P)) * (1/(1+d))
 *
 * */
#define dot3(N,V) (N[0]*V[0]+N[1]*V[1]+N[2]*V[2])

void ssao(float *depth, int nx, int ny, float *out)
{

   for(int y=0;y<ny;y++)
   for(int x=0;x<nx;x++)
   {
      int current_pos = p_sym(nx,ny,x,y);

      // estimate the direction of maximum slope of the surface depth
      // for that compute the gradient vector
      // test different gradient schemes keep only the maximum gradient
      int Ngs=4;
      int gs[4][2] = { {1,1}, {1,-1}, {-1,1}, {-1,-1} };
      float dx=0,dy=0;
      for(int t=0;t<Ngs;t++) {
         int tmp_pos;
         tmp_pos= p_sym(nx,ny,x+gs[t][0],y);
         float tdx= (depth[tmp_pos] - depth[current_pos])*gs[t][0];
         tmp_pos= p_sym(nx,ny,x,y+gs[t][1]);
         float tdy= (depth[tmp_pos] - depth[current_pos])*gs[t][1];
         if(hypot(dx,dy) < hypot(tdx,tdy)){
            dx=tdx;
            dy=tdy;
         }
      }
// centered differences
//      dx = depth[p_sym(nx,ny,x+1,y)] - depth[p_sym(nx,ny,x-1,y)];
//      dy = depth[p_sym(nx,ny,x,y+1)] - depth[p_sym(nx,ny,x,y-1)];
//
//
      // We don't trust our gradients too much, specially the small ones. 
      // The small gradients may be due to quantization of the depth map, 
      // so we flatten them if they are smaller than a threshold.
      // We use the function f(x) = |x|/sqrt(eps^2 + |x|^2), where the 
      // parameter eps indicates the quantization value, below which 
      // the gradients are scaled quadratically.
      float EPS=1;
      float tmp=dx*dx+dy*dy;
      dx = dx*tmp/sqrt(EPS*EPS + tmp);
      dy = dy*tmp/sqrt(EPS*EPS + tmp);


      // Now determine the normal vector
      // given the gradient \nabla u we define the tangent to the surface
      //   T = \nabla u / |\nabla u| + |\nabla u| x Z
      // the normal is then
      //   N = (-\nabla u + Z)/|-\nabla u + Z|
      float nnorm = sqrt(dx*dx+dy*dy+1);
      float N[3]={-dx/nnorm,-dy/nnorm,1./nnorm}; 

      int SAMPLES=50;   // numner of samples considered
      int RADIUS=10;    // search the samples within the radius
      int SIGN=-1;      // normal orientation
      float ppow=1;     // pow for the decay of the shading
      for(int s=0;s<SAMPLES;s++)
      {
         int rand_x=rand()/(1.+RAND_MAX)*2*RADIUS-RADIUS;
         int rand_y=rand()/(1.+RAND_MAX)*2*RADIUS-RADIUS;
         int rand_pos = p_sym(nx,ny,x+rand_x,y+rand_y);

         // vector joining the current point P and a random neighbor P'
         float V[3]={rand_x,rand_y,depth[rand_pos] - depth[current_pos]};
         float d=sqrt(dot3(V,V));
         out[current_pos] += fmax(0, SIGN*dot3(N,V))* powf( 1./(1.+d), ppow);
      }
      
   }
}

int main (int argc, char **argv)
{
   /* ppatameter parsing - parameters*/
   if(argc<3) 
   {
      fprintf (stderr, "too few parameters\n");
      fprintf (stderr, "Screen Space Ambient Occlusions: takes a depth map and produces a shadow map\n");
      fprintf (stderr, "   usage: %s in out\n",argv[0]);
      return 1;
   }

   int nc,nr,nch;
   float *in = iio_read_image_float_vec(argv[1], &nc, &nr, &nch);
   float *out = malloc(nc*nr*nch*sizeof*out);

   ssao(in,nc,nr,out);

   iio_save_image_float_vec(argv[2], out, nc, nr, nch);
   free(in);
   free(out);

   return 0;
}



