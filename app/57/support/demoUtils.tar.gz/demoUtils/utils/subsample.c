#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include "iio.h"


int main (int argc, char **argv)
{
   int dx = 0;
   int dy = 0;
   int sx = 1;
   int sy = 1;

   /* ppatameter parsing - parameters*/
   if(argc<3) 
   {
      fprintf (stderr, "too few parameters\n");
      fprintf (stderr, "subsample an image by steps sx and sy (integers), taking the sample displaced by (dx,dy)\n");
      fprintf (stderr, "   usage: %s in out [sx(=1) [sy(=1) [dx(=0) [dy(=0)]]]] \n",argv[0]);
      return 1;
   }

   if(argc>=4) sx = atoi (argv[3]);
   if(argc>=5) sy = atoi (argv[4]);
   if(argc>=6) dx = atoi (argv[5]);
   if(argc>=7) dy = atoi (argv[6]);
   assert (sx>0 && sy>0 && dx>=0 && dy>=0);


   int nc,nr,nch;
   float *in = iio_read_image_float_vec(argv[1], &nc, &nr, &nch);

   int nc2 = (nc-dx)/sx,    nr2 = (nr-dy)/sy;
   float *out = malloc(nc2*nr2*nch*sizeof*out);

   for(int y=0;y<nr2;y++)
   for(int x=0;x<nc2;x++)
   for(int c=0;c<nch;c++)
      out[c+(x+y*nc2)*nch] = in[c+(x*sx+dx + (y*sy+dy)*nc)*nch];

   iio_save_image_float_vec(argv[2], out, nc2, nr2, nch);

   free(in);
   free(out);

   return 0;
}



