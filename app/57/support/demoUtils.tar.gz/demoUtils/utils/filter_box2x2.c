#include <stdio.h>
#include <stdlib.h>
#include "dct.h"
#include "iio.h"

#define max(a,b) (((a)>(b))?(a):(b))
#define min(a,b) (((a)<(b))?(a):(b))


// runs the filter 1/4[1,1;1,1] in the fourier domain, symmetrizing the image (when filt_2 = 1)
// or else the filter [.03,.06,.03;.06,.6,.06;.03,.06,.03] in the fourier domain, symmetrizing the image
void filter_high_freq (float *in, int nx, int ny) {
	int i;

   // alloc memory
   float *inhat = malloc(nx*ny*sizeof*inhat);
   float *fhat  = malloc(nx*ny*sizeof*fhat);
   float *f     = malloc(nx*ny*sizeof*f);

   // initialize the box(2x2) filter
	for (i=0;i<nx*ny;i++) f[i]=0.0;
   f[0]=.25*sqrt(nx*ny*4);

   // apply the dct's
   dctII_2d(inhat,in,nx,ny);
   dctII_2d(fhat,f,nx,ny);

   // multiply
	for (i=0;i<nx*ny;i++) inhat[i]*=fhat[i];

   // inverse dct
   idctII_2d(in,inhat,nx,ny);

	free(f);
	free(fhat);
	free(inhat);
}




int main(int argc,char* argv[])
{
	// command line
	if( argc < 3)
	{
		fprintf(stderr,"%s - removes high frequency artifacts\n", argv[0]);
		fprintf(stderr,"usage: %s in out\n",argv[0]);
		exit(1);
	}

	// Read the image from the input 
   int i,c,nc,nr,nch;
   float *x = iio_read_image_float_split(argv[1], &nc, &nr, &nch);
   for (c=0;c<nch;c++) {
      // run the filter
      filter_high_freq(x+nc*nr*c,nc,nr);
   }
   // write the result
   iio_save_image_float_split(argv[2], x, nc, nr, nch);
   free(x);
	return 0;
}


