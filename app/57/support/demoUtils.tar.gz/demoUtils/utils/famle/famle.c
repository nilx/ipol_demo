/*------------------------- MegaWave2 Module -------------------------*/
/* mwcommand
name = {famle};
version = {"1.2"};
author = {"Jean-Pierre D'Ales, Jacques Froment, Catalina Sbert"};
function = {"Level line image interpolation using the AMLE model"};
usage = {
  'i':image_init->Init "Initial condition image",
  'n':[n=1000]->n "Number of iterations for the implicit Euler scheme",
  'w':[omega=1.8]->omega [0.01,1.99] "Relaxation parameter, must be in ]0,2[",
  't':[ht=1.0]->ht "Time increment",
  's':mse->mse "Stop if the MSE between two iterations is lower than mse",
  input->Input  "Original fimage with missing level lines",
  output<-Output "Output fimage with interpolated level lines"
  };
*/
/*-------------------------------------------------------------------*/

#include <stdio.h>
#include <math.h>
#include "iio.h"
#include "fimage.h"

#define EPS 1e-4


static void NORM_IMG(Fimage image)
   /*--- Normalize `image` to 0.0 mean and 1.0 variance ---*/
{
   long l, c;                  /* Index of current point in `image` */
   long dx, dy;                /* Size of image */
   double mean, var;           /* Mean and variance of `image` */

   dx = image->ncol;
   dy = image->nrow;

   mean = 0.0;
   for (l = 0; l < dy; l++)
      for (c = 0; c < dx; c++)
         mean += image->gray[dx * l + c];
   mean /= (double) dx *dy;
   for (l = 0; l < dy; l++)
      for (c = 0; c < dx; c++)
         image->gray[dx * l + c] -= mean;

   var = 0.0;
   for (l = 0; l < dy; l++)
      for (c = 0; c < dx; c++)
         var += image->gray[dx * l + c] * image->gray[dx * l + c];
   var = sqrt(((double) dx * dy - 1.0) / var);
   for (l = 0; l < dy; l++)
      for (c = 0; c < dx; c++)
         image->gray[dx * l + c] *= var;

}

void fmse(Fimage Img1, Fimage Img2, int *Norm, char *PsnrFlg, double *SNR,
      double *PSNR, double *MSE, double *MRD)
/*--- Computes the mean square error between Img1 and Img2 ---*/
/* Input images */
/* Normalisation to 0 mean and 1.0 variance */
/* Alternative computation for the PSNR */
/* Signal to noise ratio / `Img1` */
/* Peak signal to noise ratio / `Img1` */
/* Mean square error between Img1 and Img2 */
/* Maximal relative difference */
{
   long l, c;                  /* Index of current point in `Img1`, `Img2` */
   long ldx;
   long dx, dy;                /* Size of image */
   double diff;                /* Difference between two values */
   double min1, max1;          /* Minimum and maximum of `Img1` values */
   double min, max;            /* Minimum and maximum of `Img1` and `Img2`
                                * values */
   double mean1;               /* Mean value of `Img1` */
   double var1;                /* Empirical variance of `Img1` */
   double DMAX;                /* Absolute value of the maximum difference
                                * between values of `Img1` and `Img2` */


   dx = Img1->ncol;
   dy = Img1->nrow;

   /*--- Normalisation of images (if selected) ---*/

   if (Norm)
   {
      NORM_IMG(Img1);
      NORM_IMG(Img2);
   }

   /*--- Computation of minimum and maximum values in `Img1` ---*/
   /*--- and over `Img1` and `Img2` ---*/

   min = min1 = 1e30;
   max = max1 = -min1;

   ldx = 0;
   for (l = 0; l < dy; l++)
   {
      for (c = 0; c < dx; c++)
      {
         if (Img1->gray[ldx + c] < min1)
         {
            min1 = Img1->gray[ldx + c];
            if (Img1->gray[ldx + c] < min)
               min = min1;
         }
         if (Img1->gray[ldx + c] > max1)
         {
            max1 = Img1->gray[ldx + c];
            if (Img1->gray[ldx + c] > max)
               max = max1;
         }
         if (Img2->gray[ldx + c] < min)
            min = Img2->gray[ldx + c];
         if (Img2->gray[ldx + c] > max)
            max = Img2->gray[ldx + c];
      }
      ldx += dx;
   }

   /*--- Computation of variance of `Img1` ---*/

   mean1 = 0.0;
   if (!Norm)
   {
      ldx = 0;
      for (l = 0; l < dy; l++)
      {
         for (c = 0; c < dx; c++)
            mean1 += Img1->gray[ldx + c];
         ldx += dx;
      }
      mean1 /= (double) dx *dy;
   }

   var1 = 0.0;
   ldx = 0;
   for (l = 0; l < dy; l++)
   {
      for (c = 0; c < dx; c++)
         var1 +=
            (Img1->gray[ldx + c] - mean1) * (Img1->gray[ldx + c] - mean1);
      ldx += dx;
   }
   var1 /= ((double) dx * dy - 1.0);

   /*--- Computation of m.s.e. and s.n.r. ---*/

   DMAX = 0.0;
   *MSE = 0.0;
   ldx = 0;
   for (l = 0; l < dy; l++)
   {
      for (c = 0; c < dx; c++)
      {
         diff = fabs((double) Img1->gray[ldx + c] - Img2->gray[ldx + c]);
         if (diff > DMAX)
            DMAX = diff;
         *MSE += diff * diff;
      }
      ldx += dx;
   }

   *MSE /= (double) dx *dy;
   if (var1 == 0.0)
   {
      *SNR = 0.0;
   }
   else
      *SNR = 10.0 * log10(var1 / (*MSE));

   if (PsnrFlg)
   {
      *PSNR = 10.0 * log10(255.0 * 255.0 / (*MSE));
   }
   else
   {
      if (max1 == min1)
      {
         *PSNR = 10.0 * log10(255.0 * 255.0 / (*MSE));
      }
      else
         *PSNR = 10.0 * log10((max1 - min1) * (max1 - min1) / (*MSE));
      /*
       * printf("true PSNR = %lg\n",
       * 10.0 * log10((255.0*255.0)/((max1 - min1)* (max1 - min1))) + *PSNR);
       */
   }

   if (max == min)
      *MRD = 0.0;
   else
      *MRD = 100.0 * DMAX / (max - min);

   /*--- Printing of results ---*/


}


/* Compute the 8 neighbour pixels of the current pixel p              */
/* When p touches the border of the image, a mirror effect is applied */

void neighbor(int x,int y,int xmax,int ymax,float *p,float **left,float **right,float **up,float **down,float **right_down,float **left_up,float **right_up,float **left_down)

{
   if (x>0) 
   {
      *left = p-1; 
      if (x < xmax) 
      {
         *right = p+1; 
         if (y>0) 
         {
            *up =p-xmax-1; 
            if (y < ymax) 
            { /* 0 < x < xmax  0 < y < ymax */
               *down=p+xmax+1; 
               *right_down=p+xmax+2;
               *left_up=p-xmax-2;
               *right_up=p-xmax;
               *left_down=p+xmax;
            }
            else /* 0 < x < xmax   y = ymax */
            {
               *down=*up;
               *right_up = *right_down= p-xmax;
               *left_up = *left_down= p-xmax-2;
            }
         } 
         else /* 0 < x < xmax   y = 0 */ 
         {
            *down= p+xmax+1;
            *up=*down;
            *right_up = *right_down=p+xmax+2;
            *left_up = *left_down=p+xmax;
         }
      }
      else /* x = xmax */
      {
         *right=*left;
         if (y>0) 
         {
            *up=p-xmax-1; 
            if (y < ymax) 
            { /* x = xmax  0 < y < ymax */
               *down=p+xmax+1; 
               *right_down = *left_down = p+xmax;
               *right_up = *left_up = p-xmax-2;
            }
            else /* x = xmax   y = ymax */
            {
               *down=*up;
               *right_up = *left_up = *left_down = *right_down = p-xmax-2;
            }
         }
         else /* x = xmax  y = 0 */
         {
            *down=p+xmax+1;
            *up=*down;
            *right_up = *right_down = *left_up = *left_down= p+xmax;
         }
      }
   }
   else /* x = 0 */
   {
      *right=p+1;
      *left=*right;
      if (y>0) 
      {
         *up=p-xmax-1; 
         if (y < ymax) 
         { /* x = 0  0 < y < ymax */
            *down=p+xmax+1; 
            *right_down=p+xmax+2;
            *right_up=p-xmax;
            *left_up=*right_up;
            *left_down=*right_down;
         }
         else /* x = 0   y = ymax */
         {
            *down=*up;
            *right_up = *left_up = *left_down = *right_down = p-xmax;
         }
      } 
      else /* x = 0   y = 0 */ 
      {
         *down=p+xmax+1;
         *up=*down;
         *right_up = *left_up = *left_down = *right_down = p+xmax+2;
      }
   }
}

/* Compute the new gray value of the current point (x,y) by solving an implicit Euler scheme */
/* of the PDE du/dt = D2u (Du/|Du|, Du/|Du|)                                                 */

void compute_point(int x,int y,int xmax,int ymax,float *p,float prev_value,float ht,float omega)

{
   float *left,*right,*up,*down,*right_down,*left_up,*right_up,*left_down;
   float ux,uy,uxx,uyy,uxy;
   double A,B,NG2;

   neighbor(x,y,xmax,ymax,p,&left,&right,&up,&down,&right_down,&left_up,&right_up,&left_down);

   ux = *right - *left;
   uy = *down - *up;
   uxx = *right + *left;
   uyy = *down + *up;
   uxy = ( *right_down + *left_up) - ( *right_up + *left_down);

   NG2 = ux*ux + uy*uy;
   if ( fabs(NG2) > EPS )
   {
      A=(2+4*ht)*NG2*(*p) - 2*prev_value*NG2 - 2*ht*uxx*ux*ux - 2*ht*uyy*uy*uy - ht*ux*uy*uxy;
      B=2*NG2*(1+2*ht)+EPS;
   }
   else
   {
      A=*p - 0.25*(*left + *right + *up + *down);
      B=omega;
   }

   *p -= (omega * A) / B;
}


void famle(Fimage Init,Fimage Input,Fimage Output,float *omega,int *n,float *ht,float *mse)
{
   float *ptrIn;
   float *ptrOut,*ptrPrev;
   int iter,x,y,xmax,ymax;
   Fimage Prev=NULL;			/* image at current iteration -1 */
   double msef, mrd, snr, psnr;
   float absdiff,MSE;

   xmax = Input->ncol-1;
   ymax = Input->nrow-1;

   // Output = mw_change_fimage(Output,Input->nrow,Input->ncol);
   if (Output==NULL) fprintf(stderr,"Not enough memory.\n");

   /*--- Copy the initial condition Cimage into the output Fimage ---*/

   if (Init) 
   {
      if ((Init->ncol == Input->ncol) && (Init->nrow == Input->nrow))
         for (x=0, ptrIn=Init->gray, ptrOut=Output->gray; x < Input->ncol*Input->nrow; x++) 
            *(ptrOut++) = *(ptrIn++);
      else
         fprintf(stderr, "Bad size for initial condition image image_init!\n -> -i option ignored.\n");
   }

   /*--- Copy the input Cimage into the output Fimage ---*/

   for (x=0, ptrIn=Input->gray, ptrOut=Output->gray; x < Input->ncol*Input->nrow; x++, ptrOut++, ptrIn++) 
      if (*ptrIn != 0) 
         *ptrOut = *ptrIn;

   Prev = new_fimage2(Input->ncol, Input->nrow );
   //  Prev = mw_change_fimage(NULL,Input->nrow,Input->ncol);
   if (Prev==NULL) fprintf(stderr,"Not enough memory.\n");

   for (iter=1;iter<=*n;iter++) {

      copy_fimage(Prev,Output);

      /*--- Compute the interpolation only at points not belonging ---*/
      /*--- to a level line (i.e. points with gray levels = 0) ---*/

      /*--- First pass : from left to right and up to down ---*/

      ptrIn=Input->gray;
      ptrOut=Output->gray;
      ptrPrev=Prev->gray;
      for (y=0; y<Input->nrow;y++)
         for (x=0; x<Input->ncol;x++,ptrOut++,ptrPrev++)
            if (*(ptrIn++) == 0) compute_point(x,y,xmax,ymax,ptrOut,*ptrPrev,*ht,*omega);

      /*--- Second pass : from right to left and down to up ---*/

      ptrIn--; 
      ptrOut--;
      ptrPrev--;
      for (y=Input->nrow-1; y>=0; y--)
         for (x=Input->ncol-1; x>=0; x--,ptrOut--,ptrPrev--)
            if (*(ptrIn--) == 0) compute_point(x,y,xmax,ymax,ptrOut,*ptrPrev,*ht,*omega);

      if ((iter % 1000)==0) printf("%d/%d done.\n",iter,*n);

      /*--- Stop before the end if maxabsdiff <= *eps ---*/

      if (mse != NULL)
      {
         MSE=0.0;
         ptrOut=Output->gray;
         ptrPrev=Prev->gray;
         for (y=0; y<Input->nrow;y++)
            for (x=0; x<Input->ncol;x++,ptrOut++,ptrPrev++)
            {
               absdiff = fabs((double) *ptrOut - *ptrPrev);
               MSE += absdiff*absdiff;
            } 
         MSE /= ((float) Input->nrow * Input->ncol);
         if (MSE <= *mse) 
         {
            printf("MSE = %f : stop at iteration %d\n",MSE,iter);
            iter=*n+1;
         }
      }
   }

   printf("Images difference between iterations %d and %d\n",*n-1,*n); 
   fmse(Prev, Output, NULL, NULL, &msef, &mrd, &snr, &psnr);

   del_fimage(Prev);
}


void famle_color(Fimage Init,Fimage Input,Fimage Output,float *omega,int *n,float *ht,float *mse)
{
   int nc = Input->ncol, nr =Input->nrow, nch = Input->nch;
   int N=nc*nr;

   Fimage ti  = new_fimage3(NULL,nc,nr,1);
   Fimage ti2 = new_fimage3(NULL,nc,nr,1);
   Fimage to  = new_fimage3(NULL,nc,nr,1);

   if( Init && (Init->nch != nch) ) {
      fprintf(stderr, "# of channels of inputs do not match\n");
      exit(1);
   }

   for (int c=0;c<nch;c++){
      for(int i=0;i<N;i++) ti->gray[i] = Input->gray[i*nch+c];
      if(Init) {
         for(int i=0;i<N;i++) ti->gray[i] = Init->gray[i*nch+c];
         famle(ti2,ti,to,omega,n,ht,mse);
      } else { 
         famle(NULL,ti,to,omega,n,ht,mse);
      }
      for(int i=0;i<N;i++) Output->gray[i*nch+c] = to->gray[i];
   }
   del_fimage(ti);
   del_fimage(ti2);
   del_fimage(to);
}

Fimage fimageread(char* name) 
{
   int nx,ny,nc;
   float *fdisp = iio_read_image_float_vec(name, &nx, &ny, &nc);
   return new_fimage3(fdisp, nx,ny,nc);
}

void fimagewrite(char* name, Fimage i) 
{
   iio_save_image_float_vec(name, i->gray, i->ncol, i->nrow, i->nch);
}

int main(int argc, char **argv) 
{

   if(argc<2) 
   {
      printf(" -------------------------------------------------------------------------------                \n");
      printf("     \\     //  Level line image interpolation using the AMLE model.                            \n");
      printf("      \\   //                                                                                   \n");
      printf("       famle    Author(s) : Jean-Pierre D'Ales, Jacques Froment, Catalina Sbert.                \n");
      printf(" -------------------------------------------------------------------------------                \n");
      printf("                                                                                                \n");
      printf(" usage : famle input output image_init [n] [omega] [ht] [mse]                                   \n");
      printf("                                                                                                \n");
      printf("        input :  Original fimage with missing level lines                                       \n");
      printf("        output : Output fimage with interpolated level lines                                    \n");
      printf("        image_init :   Initial condition image                                                  \n");
      printf("        n (default 1000) :   Number of iterations for the implicit Euler scheme                 \n");
      printf("        omega (in [0.01,1.99], default 1.8) :  Relaxation parameter, must be in ]0,2[           \n");
      printf("        ht (default 1.0) :   Time increment                                                     \n");
      printf("        mse : Stop if the MSE between two iterations is lower than mse                          \n");
      exit(1);


   }
   int n=1000;
   float omega = 1.8;
   float ht = 1.0;
   float mse = 0;
   Fimage Init = NULL;
   Fimage Input = fimageread(argv[1]);
   Fimage Output= new_fimage3(NULL,Input->ncol, Input->nrow, Input->nch);
   if(argc>3) Init = fimageread(argv[3]);
   if(argc>4) n = atoi(argv[4]);
   if(argc>5) omega = atof(argv[5]);
   if(argc>6) ht = atof(argv[6]);
   if(argc>7) {
      mse = atof(argv[7]);
      famle_color(Init,Input,Output,&omega,&n,&ht,&mse);
   } else {
      famle_color(Init,Input,Output,&omega,&n,&ht,NULL);
   }


   fimagewrite (argv[2], Output);
}

