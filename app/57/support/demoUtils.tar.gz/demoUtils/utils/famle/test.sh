plambda im_data.png im_mask.png "x y * " > aa
./famle  aa t aa
vflip t aa
