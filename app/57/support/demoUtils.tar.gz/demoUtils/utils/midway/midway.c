#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "fimage.h"


#define max(a,b) (((a)>(b))?(a):(b))
#define min(a,b) (((a)<(b))?(a):(b))

/* auxiliar for the qsort */

typedef struct values {
  float value;
  long position;
} VALUES , *VALUESPTR;

/* auxiliar for the qsort */
int cmp (const void * a, const void * b)
{ 
   if ( ((VALUESPTR)a)->value > ((VALUESPTR)b)->value ) return 1; 
   if ( ((VALUESPTR)a)->value < ((VALUESPTR)b)->value ) return -1;
   return 0;
}


VALUESPTR his(Fimage input) {
  int y,x,c,i,j;
  int nc  = input->ncol, nr =input->nrow, nch =input->nch;

  /* build the list of gray values */
  VALUESPTR arr = calloc((long) nc*nr, sizeof(VALUES));
  for (x=0; x<nc; x++){
     for (y=0; y<nr; y++){
        i =  nc * y + x;
        arr[i].position = i;
        arr[i].value = 0;
        for (c=0; c<nch; c++) arr[i].value += input->gray[i*nch];
        arr[i].value /= (float) nch;
     }
  }

  /* sort it */
  qsort( arr , nc*nr , sizeof(VALUES) , *cmp );
   
  return arr;
}



void midway(Fimage i1, Fimage i2, Fimage o1, Fimage o2, float rho)
{
  int y,x,c,i,j;
  int nc  = i1->ncol, nr =i1->nrow, nch =i1->nch;
  int nc2 = i2->ncol, nr2=i2->nrow, nch2=i2->nch;

  float N1 = nc*nr;
  VALUESPTR H1 = his(i1);
  float N2 = nc2*nr2;
  VALUESPTR H2 = his(i2);

  
  for(i=0;i<N1;i++) 
     for (j=0;j<nch;j++) {
        float v1 = i1->gray[H1[i].position*nch+j];
        float v2;

        float pos2 = ((float)i)/(N1-1)*(N2-1);
        float pos2f = max(floor(pos2),0);
        float pos2c = min(ceil(pos2),N2);
        if(pos2 == floor(pos2)) {
           v2 = i2->gray[H2[(int)pos2].position*nch+j];
        }
        else {
           v2 = (1 - (pos2c - pos2)) * i2->gray[H2[(int)pos2c].position*nch+j]  +  (1-(pos2-pos2f)) * i2->gray[H2[(int)pos2f].position*nch+j]  ;
        }
        o1->gray[H1[i].position*nch+j] = rho*v1 + (1-rho)*v2;
//        o1->gray[H1[i].position*nch+j] = rho*i1->gray[H1[i].position*nch+j] + (1-rho)*i2->gray[H2[(int)round(((float)i)/N1*N2)].position*nch+j];
     }

  for(i=0;i<N2;i++) 
     for (j=0;j<nch2;j++){
        float v1;
        float v2 = i2->gray[H2[i].position*nch+j];

        float pos1 = ((float)i)/(N2-1)*(N1-1);
        float pos1f = max(floor(pos1),0);
        float pos1c = min(ceil(pos1),N1);
        if(pos1 == floor(pos1)) {
           v1 = i1->gray[H1[(int)pos1c].position*nch+j];
        }
        else {
           v1 = (1 - (pos1c - pos1)) * i1->gray[H1[(int)pos1c].position*nch+j]  +  (1-(pos1-pos1f)) * i1->gray[H1[(int)pos1f].position*nch+j]  ;
        }

        o2->gray[H2[i].position*nch+j] = rho*v1 + (1-rho)*v2;
//        o2->gray[H2[i].position*nch+j] = rho*i2->gray[H2[i].position*nch+j] + (1-rho)*i1->gray[H1[(int)round(((float)i)/N2*N1)].position*nch+j];
     }
  
  free(H1);
  free(H2);


}






/* MAIN  */

#ifndef DONT_USE_MAIN

#include "iio.h"

extern   void fk_histogram_midway(float *in1, float *in2, float *out1, float *out2, int width1, int height1, int width2, int height2);



Fimage fimageread(char* name) 
{
   int nx,ny,nc;
   float *fdisp = iio_read_image_float_vec(name, &nx, &ny, &nc);
   return new_fimage3(fdisp, nx,ny,nc);
}

void fimagewrite(char* name, Fimage i) 
{
   iio_save_image_float_vec(name, i->gray, i->ncol, i->nrow, i->nch);
}



int main (int argc, char **argv)
{
   float t = 0;
   char *fin1= NULL;
   char *fin2= NULL;
   char *fout1= NULL;
   char *fout2= NULL;
   float rho=0.5;

   /* ppatameter parsing - parameters*/
   if(argc<5) 
   {
      fprintf (stderr, "too few parameters\n");
      fprintf(stderr,"Midway equalization of an image pair\n");
      fprintf(stderr,"usage: midway in1 in2 out1 out2 [rho(1/2)] \n");
      return 1;
   }
   if(argc>=6) 
      rho = atof (argv[5]);

   fin1 = argv[1];
   fin2 = argv[2];
   fout1= argv[3];
   fout2= argv[4];


   /* program call */

   Fimage in1 = fimageread(fin1);
   Fimage in2 = fimageread(fin2);

   Fimage out1 = new_fimage3(NULL, in1->ncol, in1->nrow, in1->nch);
   Fimage out2 = new_fimage3(NULL, in2->ncol, in2->nrow, in2->nch);

   //fk_histogram_midway(in1->gray, in2->gray, out1->gray, out2->gray, in1->ncol, in1->nrow, in2->ncol, in2->nrow);
   midway(in1,in2,out1,out2,rho);

   fimagewrite (fout1, out1);
   fimagewrite (fout2, out2);

   /* free memory (the program ends here) */

   return 0;
}
#endif
