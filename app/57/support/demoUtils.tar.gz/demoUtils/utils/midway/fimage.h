#ifndef DIMAGE_FACCIOLO_H
#define DIMAGE_FACCIOLO_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

/* declarations */
typedef struct fimage {
	int offrow;
	int offcol;
	int nrow;
	int ncol;
   int nch;
	float *gray;
} *Fimage;

static Fimage new_fimage(void);

static Fimage new_fimage2(int nx, int ny);

static Fimage new_fimage3(float*im, int nx, int ny, int nc);

static Fimage clone_fimage(Fimage i);

static void del_fimage(Fimage i) ;

static Fimage copy_fimage(Fimage dest, Fimage src);


/* definitions */
Fimage new_fimage(void)
{
	Fimage image;

	if ( !(image = calloc(1,sizeof(struct fimage))) ) 
	{
		fprintf(stderr, "[new_fimage] Not enough memory\n");
		exit(1);
		return(NULL);
	}

	image->nrow = image->ncol = image->nch = 0; 
	image->offrow = image->offcol = 0;
	image->gray = NULL;
	return(image);
}


Fimage new_fimage2(int nx, int ny){
	Fimage t= new_fimage();
	t->offrow = t->offcol = 0;
	t->ncol = nx;
	t->nrow = ny;
   t->nch  = 1;
	if ( !(t->gray = calloc(t->ncol*t->nrow,sizeof(float))))
	{
		fprintf(stderr, "[new_fimage2] Not enough memory\n");
		exit(1);
		return(NULL);
	}
	return (t);
}

Fimage new_fimage3(float *im, int nx, int ny, int nc){
	Fimage t= new_fimage();
	t->offrow = t->offcol = 0;
	t->ncol = nx;
	t->nrow = ny;
   t->nch  = nc;
   if (im) t->gray = im;
   else {
      if ( !( t->gray = calloc(t->ncol*t->nrow*t->nch, sizeof(float))))
      {
         fprintf(stderr, "[new_fimage2] Not enough memory\n");
         exit(1);
         return(NULL);
      }
   }
	return (t);
}

Fimage clone_fimage(Fimage i){
   Fimage t = new_fimage3(NULL, i->ncol, i->nrow, i->nch);
   copy_fimage(t, i);
	return (t);
}


void del_fimage(Fimage i) {
	if (i->gray) free(i->gray);
	free(i);
}

Fimage copy_fimage(Fimage dest, Fimage src){
	if ((dest->ncol == src->ncol) && (dest->nrow == src->nrow)){
		memcpy(dest->gray,src->gray,src->ncol*src->nrow*src->nch*sizeof(float)); 
	} else {
		fprintf(stderr, "[copy_fimage] Image sizes does not match\n");
	}
	return dest;
}

/* access to the pixel in the image u at the position [i (column) ,j (row) ] */
#define _(u,i,j) ((v)->f[ (u)->nch * ( (j) * (u)->ncol + (i)) ] )
/* index of the pixel in the image u, at position [i (column) ,j (row) ] */
#define ii(v,i,j) ( (u)->nch * ((j) * (v)->ncol + (i))  )

#endif
