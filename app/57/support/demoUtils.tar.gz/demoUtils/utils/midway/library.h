#ifndef _LIBRARY_H_
#define _LIBRARY_H_

#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <cstring>
#include <iostream>
#include <cmath>
#include <math.h>
#include <fftw3.h>
#include <assert.h>


#ifndef PI
#define PI 3.14159265358979323846264338327
#endif
#ifndef M_PI
#define M_PI 3.14159265358979323846264338327
#endif



#define dTiny 1e-10
#define fTiny 0.00000001f
#define fLarge 100000000.0f






namespace libIIP {
	
	
	#define IIPMAX(i,j) ( (i)<(j) ? (j):(i) )
	#define IIPMIN(i,j) ( (i)<(j) ? (i):(j) )

	
	///////////////////////
	//! Value operations
	///////////////////////
	
	// Basic
	void fpClear(float *fpI,float fValue, int iLength);
	void fpCopy(float *fpI,float *fpO, int iLength);

	
	float fpMax(float *u,int *pos, int size);
	float fpMin(float *u,int *pos,int size);

	
	float fpVar(float *u,int size);	
	float fpMean(float *u,int size);
	
	
    void fpCombine(float *u,float a,float *v,float b, float *w,  int size);
    
	void fpBinarize(float *u, float *v, float value, int inverse, int size);
	
    
    // Distance
    
    float fpDistLp(float *u, float *v, int p, int size);
    float fpDistLp(float *u, float *v, float *m, int p, int size);
  
    
    
	
	// Add noise
	void fpAddNoise(float *u, float *v, float std, long int randinit, int size); 
	void fpAddNoiseAfine(float *u,float *v, float a,float b,long int randinit, int size);
	
	void fiComputeImageGradient(float * tpI,float * tpGrad, float * tpOri, int iWidth, int iHeight);

	
    void fiImageDrawCircle(float *igray, int pi,int pj, double radius, float value, int width, int height);	
    void fiImageDrawLine(float *igray, int a0, int b0, int a1, int b1, float value, int width, int height);
  
    
    
	
	///////////////////////
	//! Float pointer ordering
	///////////////////////
	
	void fpQuickSort(float *fpI, int iLength, int inverse = 0 );
	
	void fpQuickSort(float *fpI, float *fpO, int iLength, int inverse = 0);
	

	
	
	
	///////////////////////
	//! Image Convolution
	///////////////////////
	
	// kernels
	float* fiFloatGaussKernel(float std, int & size);
	float * fiFloatDirectionalGaussKernel(float xsigma, float ysigma, float angle, float *kernel, int kwidth, int kheight);
	
	
	// Auxiliary functions
	void fiFloatBufferConvolution(float *buffer,float *kernel,int size,int ksize);
	void fiFloatHorizontalConvolution(float *u, float *v, int width, int height, float *kernel, int ksize, int boundary);
	void fiFloatVerticalVonvolution(float *u, float *v, int width, int height, float *kernel,int ksize, int boundary);
	
	
	// Convolution functions
	void fiGaussianConvol(float *u, float *v, int width, int height, float sigma);
	void fiConvol(float *u,float *v,int width,int height,float *kernel,int kwidth,int kheight);
	void fiSepConvol(float *u,float *v,int width,int height,float *xkernel, int xksize, float *ykernel, int yksize);
	
	
	
	
	///////////////////////
	//! Image Conversion
	///////////////////////
	
	
#define COEFF_YR 0.299
#define COEFF_YG 0.587
#define COEFF_YB 0.114
	void fiRgb2Yuv(float *r,float *g,float *b,float *y,float *u,float *v,int width,int height);
	void fiYuv2Rgb(float *r,float *g,float *b,float *y,float *u,float *v, int width,int height);
	
	
	void fiRgb2YuvO(float *r,float *g,float *b,float *y,float *u,float *v,int width,int height);
	void fiYuvO2Rgb(float *r,float *g,float *b,float *y,float *u,float *v, int width,int height);
	
	
	
	
	
	///////////////////////
	//! Spline Interpolation
	///////////////////////
	
	float v(float *in,int x,int y,float bg, int width, int height);
	void keys(float *c,float t,float a);
	void spline3(float *c,float t);
	void init_splinen(float *a,int n);
	void splinen(float *c,float t,float *a,int n);
	
	
	void finvspline(float *in,int order,float *out, int width, int height);
	
	
	
	///////////////////////
	//! Miscellaneous
	///////////////////////
#define LUTMAX 30.0
#define LUTMAXM1 29.0
#define LUTPRECISION 1000.0
	
	
	void  wxFillExpLut(float *lut, int size);
	float wxSLUT(float dif, float *lut);

	
	
	///////////////////////
	//! Patch Distances
	///////////////////////
	
	float fiL2FloatDist(float **u0,float **u1,int i0,int j0,int i1,int j1,int radius,int channels, int width0, int width1);
	float fiL2FloatDist(float *u0,float *u1,int i0,int j0,int i1,int j1,int radius,int width0, int width1);
	
	
	float fiL2FloatWDist ( float * u0, float *u1, int i0, int j0,int i1,int j1,int radius, float *kernel, int width0, int width1);
	float fiL2FloatWDist ( float * u0, float *u1, int i0, int j0,int i1,int j1,int xradius, int yradius, float *kernel, int width0, int width1);
	float fiL2FloatWDist ( float ** u0, float **u1,int i0,int j0,int i1,int j1,int radius, float *kernel, int channels, int width0, int width1);
	
}
#endif




