./midway ../testdata/1.tif ../testdata/r.png  a.png b.png 
./midway ../testdata/1.tif ../testdata/r.png  a.1.png b.1.png .1
vflip *.png
rm *.png
