#include "libhistogram.h"

/**
 * @file  libhistogram.cpp
 * @brief Histogram specification
 *
 * @author Antoni Buades
 */



namespace libIIP {
	
	
	/**
	 * \brief  Specificate two images to midway histogram (8 bit images)
	 *		 
	 *		@f$ O_1 = H^{-1} \ast H_1(I_1) @f$
	 *
	 *		@f$ O_2 = H^{-1} \ast H_2(I_2) @f$
	 *
	 *		being @f$ H^{-1} = 0.5 (H_1^{-1} + H_2^{-1}) @f$
	 * 
	 *
	 * @param[in]  in1,in2					input images. Images in [0, Max]
	 * @param[out] out1,out2				output images 
	 * @param[in]  width1, height1			size of the first image
	 * @param[in]  width2, height2			size of the second image
	 *
	 *
	 * \date  1 / 03 / 2011 
	 */
	
	
	void fk_histogram_midway(float *in1, float *in2, float *out1, float *out2, int width1, int height1, int width2, int height2)
	{
		
		// compute max and min
		float fRangeMax;
		float fRangeMin;
		
		fRangeMax =   fpMax(in1, NULL, width1 * height1);
		fRangeMax =   IIPMAX(fRangeMax, fpMax(in2, NULL, width1 * height1));
		
		fRangeMin =   fpMin(in1, NULL, width2 * height2);
		fRangeMin =   IIPMIN(fRangeMin, fpMin(in2, NULL, width2 * height2));
		
		
		
		// if negative values 
		
		if (fRangeMin < 0.0f) { std::cout << "warning (fk_histogram_midway) : negative values clipped to zero\n";}
		
		
		
		// memory
		
		int iRangeMax = (int) rintf(fRangeMax) + 1;
		
		float *histo1 = new float[iRangeMax];
		float *histo2 = new float[iRangeMax];
		
		float *histoInverse1 = new float[NB_CASES + 1];
		float *histoInverse2 = new float[NB_CASES + 1];
		
		
		
		// compute histograms
		
		fk_fill_histo(histo1,histoInverse1, iRangeMax, in1, width1, height1);
		fk_fill_histo(histo2,histoInverse2, iRangeMax, in2, width2, height2);
		
		
		
		
		// compute average histogram
		
		float *histoAverage = new float[NB_CASES+1];
		for (int i=0; i < NB_CASES + 1; i++) histoAverage[i] = 0.0f;
		
		
		for (int k=0; k < NB_CASES + 1; k++)  
		{
			histoAverage[k] = 0.5f * (histoInverse1[k] + histoInverse2[k]);
		}
		
		
		
		
		// specificate histograms
		
		for (int k=0; k < NB_CASES + 1; k++)  
		{
			histoInverse1[k] =  histoInverse2[k] = histoAverage[k];
		}
		
		
		fk_apply_histo(histo1,histoInverse1,iRangeMax,in1, out1, width1, height1);
		fk_apply_histo(histo2,histoInverse2,iRangeMax,in2, out2, width2, height2);
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	void fk_histogram_midway_sequence(float **in, float **out, int nImages, int width, int height)
	{
		
		
		// compute max and min
		float fRangeMax;
		float fRangeMin;
		
		
		fRangeMax =   fpMax(in[0], NULL, width * height);
		fRangeMin =   fpMin(in[0], NULL, width * height);
		
		for (int ii=1; ii < nImages ; ii++)
		{
			fRangeMax =   IIPMAX(fRangeMax, fpMax(in[ii], NULL, width * height));
			
			fRangeMin =   IIPMIN(fRangeMin, fpMin(in[ii], NULL, width * height));
			
		}
		
		
		
		
		// if negative values 
		
		if (fRangeMin < 0.0f) { std::cout << "warning (fk_histogram_midway) : negative values clipped to zero\n";}
		
		
		
		// memory
		
		int iRangeMax = (int) rintf(fRangeMax) + 1;
		
		
		float **histo = new float*[nImages];
		float **histoInverse = new float*[nImages];
		
		for (int ii=0; ii < nImages; ii++)
		{
			
			histo[ii] = new float[iRangeMax];	
			histoInverse[ii] = new float[NB_CASES + 1];
			
		}
		
		
		// compute histograms
		for (int ii=0; ii < nImages; ii++)
		{
			
			fk_fill_histo(histo[ii],histoInverse[ii], iRangeMax, in[ii], width, height);
			
		}
		
		
		
		// compute average histogram
		
		float *histoAverage = new float[NB_CASES+1];
		for (int i=0; i < NB_CASES + 1; i++) histoAverage[i] = 0.0f;
		
		
		for (int k=0; k < NB_CASES + 1; k++)  
		{
			for (int ii=0; ii < nImages; ii++)
			{
				
				histoAverage[k]  += histoInverse[ii][k];
			}
			
			
			histoAverage[k] /= (float) nImages;
			
		}
		
		
		
		
		// specificate histograms
		for (int k=0; k < NB_CASES + 1; k++)  
		{
			for (int ii=0; ii < nImages; ii++)
			{
				
				histoInverse[ii][k] =  histoAverage[k];
			}
		}
		
		
		for (int ii=0; ii < nImages; ii++)
		{
			
			fk_apply_histo(histo[ii],histoInverse[ii],iRangeMax, in[ii], out[ii], width, height);
			
		}
		
		
		
	}
	
	
	
	/**
	 * \brief   Specificate second image to histogram of the first one (8 bit images)
	 *		   
	 *		   @f$ O = H_1^{-1} \ast H_2(I_2) @f$
	 *
	 *
	 *
	 *			
	 *			
	 * @param[in]  in1,in2					input images
	 * @param[out] out						output image
	 * @param[in]  width1, height1			size of the first image
	 * @param[in]  width2, height2			size of the second image
	 *
	 * \date  1 / 03 / 2011  
	 */
	
	
	
	void fk_histogram_specification(float *in1, float *in2, float *out, int width1, int height1, int width2, int height2)
	{
		
		
		// compute max and min
		float fRangeMax;
		float fRangeMin;
		
		fRangeMax =   fpMax(in1, NULL, width1 * height1);
		fRangeMax =   IIPMAX(fRangeMax, fpMax(in2, NULL, width1 * height1));
		
		fRangeMin =   fpMin(in1, NULL, width2 * height2);
		fRangeMin =   IIPMIN(fRangeMin, fpMin(in2, NULL, width2 * height2));
		
		
		
		// if negative values 
		
		if (fRangeMin < 0.0f) { std::cout << "warning (fk_histogram_midway) : negative values clipped to zero\n";}
		
		
		
		// memory
		
		int iRangeMax = (int) rintf(fRangeMax) + 1;
		
		float *histo1 = new float[iRangeMax];
		float *histo2 = new float[iRangeMax];
		
		float *histoInverse1 = new float[NB_CASES + 1];
		float *histoInverse2 = new float[NB_CASES + 1];
		
		
		
		// compute histograms
		
		fk_fill_histo(histo1,histoInverse1, iRangeMax, in1, width1, height1);
		fk_fill_histo(histo2,histoInverse2, iRangeMax, in2, width2, height2);
		
		
		
		
		
		// specificate histogram
		
		fk_apply_histo(histo2,histoInverse1,iRangeMax,in2, out, width2, height2);
		
		
	}
	
	
	
	
	/**
	 * \brief  Specificate histogram H to image (8 bit images)
	 *
	 * 
	 *			@f$ O = H_O^{-1} \ast H_I(I) @f$
	 *
	 *
	 * @param[in]  src						input image
	 * @param[in]  Histo					accumulated histogram of src
	 * @param[in]  HistoInverse				inverse accumulated histogram to be specified to image src
	 * @param[in]  width, height			size of the image
	 * @param[out] srt						image in modified to the specified inverse histogram
	 *
	 * \date  1 / 03 / 2011 
	 */
	
	
	
	
	
	void fk_apply_histo(float *Histo,float *HistoInverse,int iRangeMax, float *src,float *srt, int width, int height)
	{
		
		
		for (int adr=0; adr < width * height ; adr++)
		{
			
			int it = (int) rintf(src[adr]);
			if (it < 0) it=0;
			if (it >= iRangeMax) it = iRangeMax -1;
			
			
			float x = Histo[it] * NB_CASES / (float) (width * height);     /* 0<=x<=NB_CASES */
			int k= (int) rintf(x);
			
			if (k == 0) k=1;
			if (k == NB_CASES) k = NB_CASES - 1;
			
			srt[adr]=HistoInverse[k];
		}
		
	}
	
	
	
	
	
	
	/**
	 * \brief  Compute accumulated histogram and inverse accumulated histogram (8 bit images)
	 *		   
	 *
	 * 
	 *
	 * @param[in]  in						input image
	 * @param[out] Histo, HistoInverse		accumulated and inverse accumulated histograms of in
	 * @param[in]  width, height			size of the image
	 *
	 *
	 * @todo clarify inverse and make a general function to numerically inverse a table
	 *
	 * \date  1 / 03 / 2011  
	 */
	
	
	
	
	void fk_fill_histo(float *Histo,float *HistoInverse, int iRangeMax, float *in, int width, int height)
	{
		
		
		// clear data
		for (int i=0; i < iRangeMax; i++) Histo[i]=0.0f;  
		
		
		// fill histogram
		for (int i=0; i < width * height; i++)
		{
			int ivalue = rintf(in[i]);
			if (ivalue < 0) ivalue = 0;
			if (ivalue >= iRangeMax) ivalue = iRangeMax - 1;
			
			Histo[ivalue]++;
		}
		
		
		// accumulate histogram
		for (int i=1; i < iRangeMax;i++)   
			Histo[i]+=Histo[i-1]; 
		
		
		// compute the inverse histogram
		HistoInverse[0]=0.0;
		
		
		float xp=0.0;
		
		
		for (int ii=1; ii <= NB_CASES;ii++)
		{
			
			int x=-1;
			
			float aux = (float) ii * (float) width * (float) height / (float) (NB_CASES + 1); 
			
			for (int k=0; k <  iRangeMax && Histo[k] < aux; k++) {x=k;} 
			
			if (x==-1)  HistoInverse[ii]=0.0;
			else 
			{
				float dif = Histo[x+1]-Histo[x];
				
				if( fabs(dif) < 0.01)  HistoInverse[ii] =    (float) x;
				else HistoInverse[ii] =    (float) x + ((aux - Histo[x]) / (dif));
				
				HistoInverse[ii] =    IIPMAX( (float) xp,  HistoInverse[ii] );
			}
			
			xp=HistoInverse[ii];
		} 
		
		
		
	}
	
	
	
	
	
}
