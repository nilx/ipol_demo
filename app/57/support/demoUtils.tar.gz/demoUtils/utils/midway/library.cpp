#include "library.h"


namespace libIIP {
	
	
	
	/**
	 * \brief   Set value to a vector
	 *
	 *
	 * @param[in]  fpI	input vector
	 * @param[in]  fValue value to be set
	 * @param[in]  iLength	length of the vector
	 *
	 */
	void fpClear(float *fpI,float fValue, int iLength)
	{
		for (int ii=0; ii < iLength; ii++) fpI[ii] = fValue;	
	}
	
	
	
	void fpCopy(float *fpI,float *fpO, int iLength)
	{
		memcpy((void *) fpO, (const void *) fpI, iLength * sizeof(float));
	}
	
	
	
	

	float fpMax(float *u,int *pos, int size)
	{  
		float max=u[0];
		if (pos) *pos=0;  
		for(int i=1; i<size; i++)  if(u[i]>max){ max=u[i]; if (pos) *pos=i; } 
		return max;
	}
	
	
	float fpMin(float *u,int *pos,int size) 
	{
		float min=u[0];  
		if (pos) *pos=0;
		for(int i=1;i<size;i++)	if(u[i]<min){ min=u[i]; if (pos) *pos=i; }
		return min;
	}

	
	
	
	
	float  fpVar(float *u,int size)
	{
		
		float *ptru=&u[0];
		float mean=0.0;
		float mean2 = 0.0;
		for(int i=0;i<size;i++,ptru++) { mean +=  *ptru; mean2 +=  *ptru *  (*ptru);}
		
		mean/=(float) size; mean2/=(float) size;
		float var = mean2- mean*mean;
		
		var = fabsf(var);
		
		return var;
	}
	
	
	
	float  fpMean(float *u,int size)
	{
		
		float *ptru=&u[0];
		float mean=0.0;
		for(int i=0; i<size; i++,ptru++)  mean +=  *ptru;
		mean/=(float) size;
		return mean;
	}
	

	
	
    
    void fpCombine(float *u,float a,float *v,float b, float *w,  int size)
    {
        for(int i=0;i<size ;i++)   w[i]= (a *  u[i] + b* v[i]);  
        
    }
    
    
	
	void fpBinarize(float *u, float *v, float value, int inverse, int size)
	{ 
		for(int i=0;i<size;i++){
			
			if (u[i] >= value && !inverse) 	v[i]= 1.0;
			else if (u[i] <= value && inverse)  v[i]= 1.0;
			else v[i]= 0.0;
		}
	}
	
	
	/**
	 * \brief   Adds noise of standard deviation std to input vector u
	 *
	 *
	 * @param[in]   u	input vector
	 * @param[out]  v	output vector
	 * @param[in]   std	noise standard deviation
	 * @param[in]   randinit	 value used to initialize random seed
	 * @param[in]   size	length of the vector
	 *
	 */
	void fpAddNoise(float *u, float *v, float std, long int randinit, int size)   
	{
		
		srand48( (long int) time (NULL) + (long int) getpid()  + (long int) randinit);
		
		for (int i=0; i< size; i++) 
		{
			
			double a = drand48();		
			double b = drand48();
			double z = (double)(std)*sqrt(-2.0*log(a))*cos(2.0*M_PI*b);
			
			v[i] =  u[i] + (float) z;
			
		}		
		
	}
	
	
	void fpAddNoiseAfine(float *u,float *v, float a,float b,long int randinit, int size)
	{
		
		srand48( (long int) time (NULL) + (long int) getpid()  + (long int) randinit);
		
		// Gaussian noise  
		for (int i=0; i< size; i++) 
		{
			
			double std = (double) (a + b * u[i]);
			std = sqrt(std);
			
			double a0 = drand48();
			double b0 = drand48();
			double z = (double)(std)*sqrt(-2.0*log(a0))*cos(2.0*M_PI*b0);
			
			v[i] = u[i] + (float) z;
			
		}		
		
	}
	
	
	
	
    
    
    
    float fpDistLp(float *u, float *v, int p, int size)
    {
        
        float fDist = 0.0f;
        
        for (int ii=0; ii < size; ii++)
        {
            
            float dif = fabsf(u[ii] - v[ii]);
            
            
            if (p == 0) fDist = IIPMAX(fDist, dif);
            else if (p == 1)  fDist += dif;
            else if (p == 2)
                fDist += dif*dif;
            else
            {
                fDist += powf(dif, (float) p);
                
            }
            
        }
        
        fDist /= (float) size;
        
        if (p>0)
            fDist = powf(fDist, 1.0 / (float) p);
        
        
        return fDist;
        
    }
    
    
    
    float fpDistLp(float *u, float *v, float *m, int p, int size)
    {
        
        float fDist = 0.0f;
        int iCount = 0;
        
        for (int ii=0; ii < size; ii++)
            if (m[ii] > 0.0f)
            {
                
                float dif = fabsf(u[ii] - v[ii]);
                
                
                if (p == 0) fDist = IIPMAX(fDist, dif);
                else if (p == 1)  fDist += dif;
                else if (p == 2)
                    fDist += dif*dif;
                else
                {
                    fDist += powf(dif, (float) p);
                    
                }
                
                iCount++;
            }
        
        fDist /= (float) iCount;
        
        if (p>0)
            fDist = powf(fDist, 1.0 / (float) p);
        
        
        return fDist;
        
    }
    

    
    
    
    
	
	void fiComputeImageGradient(float * tpI,float * tpGrad, float * tpOri, int iWidth, int iHeight)
	{
		
		assert(tpI != NULL);

		
		if (tpGrad)	 fpClear(tpGrad, 0.0f, iWidth * iHeight);
		if (tpOri)   fpClear(tpOri, 0.0f, iWidth * iHeight);  
		
		
		
		for (int ih = 1; ih < iHeight - 1; ih++)
			for (int iw = 1; iw < iWidth - 1; iw++) {
				
				
				float xgrad = tpI[ih * iWidth + iw + 1] - tpI[ih * iWidth + iw - 1];
				
				float ygrad = tpI[(ih-1) * iWidth + iw] - tpI[(ih+1) * iWidth + iw];
				
				
				if (tpGrad) tpGrad[ih * iWidth + iw] =  sqrtf(xgrad * xgrad + ygrad * ygrad);
				
				if (tpOri) tpOri[ih * iWidth + iw] =  atan2f(-ygrad,xgrad);
				
			}
		
		
	}
	
	
	
	
	
	
	
	
	/////////////////////////////////////////////////////////////////////
	//! Float pointer ordering
	/////////////////////////////////////////////////////////////////////
	
	
	int order_float_increasing(const void *a, const void *b)
	{
		if ( *(float*)a  > *(float*)b ) return 1;
		else if ( *(float*)a  < *(float*)b ) return -1;
		
		return 0;
	}
	
	
	
	
	int order_float_decreasing(const void *a, const void *b)
	{
		if ( *(float*)a  > *(float*)b ) return -1;
		else if ( *(float*)a  < *(float*)b ) return 1;
		
		return 0;
	}
	
	
	
	
	
	
	void fpQuickSort(float *fpI, int iLength, int inverse)
	{
		
		if (inverse)
			qsort(fpI, iLength, sizeof(float), order_float_decreasing);
		else
			qsort(fpI, iLength, sizeof(float), order_float_increasing);
		
	}
	
	
	
	
	
	struct stf_qsort
	{
		float value;
		float index;
	};
	
	
	
	int order_stf_qsort_increasing(const void *pVoid1, const void *pVoid2)
	{
		struct stf_qsort *p1, *p2;
		
		p1=(struct stf_qsort *) pVoid1;
		p2=(struct stf_qsort *) pVoid2;
		
		if (p1->value < p2->value) return -1;
		if (p1->value > p2->value) return  1;
		
		return 0;
	}
	
	
	
	
	
	int order_stf_qsort_decreasing(const void *pVoid1, const void *pVoid2)
	{
		struct stf_qsort *p1, *p2;
		
		p1=(struct stf_qsort *) pVoid1;
		p2=(struct stf_qsort *) pVoid2;
		
		if (p1->value < p2->value) return 1;
		if (p1->value > p2->value) return  -1;
		
		return 0;
		
	}
	
	
	
	
	
	void fpQuickSort(float *fpI, float *fpO, int iLength, int inverse)
	{
		
		struct stf_qsort *vector = new stf_qsort[iLength];
		
		for (int i=0; i < iLength; i++)
		{
			vector[i].value = fpI[i];
			vector[i].index = fpO[i];
			
		}
		
		
		if (inverse)
			qsort(vector, iLength, sizeof(stf_qsort), order_stf_qsort_decreasing);
		else
			qsort(vector, iLength, sizeof(stf_qsort), order_stf_qsort_increasing);
		
		
		for (int i=0; i < iLength; i++)
		{
			fpI[i] = vector[i].value;
			fpO[i] = vector[i].index;
			
		}
		
		
		delete[] vector;
	}
	
	
	
	
	
	
	
	
	

	
	
	
	
	////////////////////////////////////////////////////////////////////////////////
	//! Begin Float Pointer convolutions
	////////////////////////////////////////////////////////////////////////////////
	
	float*  fiFloatGaussKernel(float std, int & size)
	{
		
		
		
		int n = 4 * ceilf(std) + 1; 
		size = n;
		
		
		float* u = new float[n];
		
		
		if (n==1)  u[0]=1.0;
		else
		{
			
			int ishift = (n-1) / 2;
			
			for (int i=ishift; i < n; i++) 
			{
				
				float v = (float)(i - ishift) / std;
				
				u[i] = u[n-1-i] = (float) exp(-0.5*v*v); 
				
			}
			
		}	
		
		
		// normalize
		float fSum = 0.0f;
		for (int i=0; i < n; i++) fSum += u[i];	
		for (int i=0; i < n; i++)  u[i] /= fSum;
		
		
		return u;
		
	}
	
	
	
	float * fiFloatDirectionalGaussKernel(float xsigma, float ysigma, float angle, float *kernel, int kwidth, int kheight)
	{
		
		int ksize = kwidth;
		
		float xsigma2 = xsigma*xsigma;
		float ysigma2 = ysigma*ysigma;
		
		int l2 = ksize/2;
		for(int y = -l2; y <= l2; y++)
			for(int x = -l2; x <= l2; x++)
			{
				
				float a = (float) angle * PI / 180.0f;
				float sina = sin(a);
				float cosa = cos(a);
				
				float ax = (float) x * cosa + (float) y * sina;
				float ay = -(float) x * sina + (float) y * cosa;
				kernel[(y+l2) * ksize + x + l2] =  exp(-(ax*ax)/(2.0f*xsigma2)  - (ay*ay)/(2.0f*ysigma2) );  
				
			}
		
		
		float sum=0.0;
		for(int i=0; i < ksize*ksize; i++) sum += kernel[i];
		for(int i=0; i < ksize*ksize; i++) kernel[i] /= sum;
		
		kwidth = ksize;
		kheight = ksize;
		
		return kernel;
	}
	
	
	
	
	
	
	
	void fiFloatBufferConvolution(float *buffer,float *kernel,int size,int ksize)
	{
		
		for (int i = 0; i < size; i++) {
			
			float sum = 0.0;
			float *bp = &buffer[i];
			float *kp = &kernel[0];
			
			
			
			int k=0;
			for(;k + 4 < ksize;  bp += 5, kp += 5, k += 5) 
				sum += bp[0] * kp[0] +  bp[1] * kp[1] + bp[2] * kp[2] +
				bp[3] * kp[3] +  bp[4] * kp[4];
			
			
			for(; k < ksize; bp++ , kp++, k++)  sum += *bp * (*kp);
			
			buffer[i] = sum;
		}
	}
	
	
	
	
	void fiFloatHorizontalConvolution(float *u, float *v, int width, int height, float *kernel, int ksize, int boundary)
	{
		
		int halfsize = ksize / 2;
		int buffersize = width + ksize;
		float *buffer = new float[buffersize];
		
		for (int r = 0; r < height; r++) {
			
			/// symmetry
			int l = r*width;
			if (boundary == 1)
				for (int i = 0; i < halfsize; i++)
					buffer[i] = u[l + halfsize - 1 - i ];
			else
				for (int i = 0; i < halfsize; i++)
					buffer[i] = 0.0;
			
			
			for (int i = 0; i < width; i++)
				buffer[halfsize + i] = u[l + i];
			
			
			if (boundary == 1)
				for (int i = 0; i <  halfsize; i++)
					buffer[i + width + halfsize] = u[l + width - 1 - i];
			else 
				for (int i = 0; i <  halfsize; i++)
					buffer[i + width + halfsize] = 0.0;
			
			fiFloatBufferConvolution(buffer, kernel, width, ksize);
			for (int c = 0; c < width; c++)
				v[r*width+c] = buffer[c];
		}
		
		
		delete[] buffer;
		
	}
	
	
	
	void fiFloatVerticalVonvolution(float *u, float *v, int width, int height, float *kernel,int ksize, int boundary)
	{
		int halfsize = ksize / 2;
		int buffersize = height + ksize;
		float *buffer = new float[buffersize];
		
		for (int c = 0; c < width; c++) {
			
			if (boundary == 1)
				for (int i = 0; i < halfsize; i++)
					buffer[i] = u[(halfsize-i-1)*width + c];
			else 
				for (int i = 0; i < halfsize; i++)
					buffer[i] = 0.0f;
			
			for (int i = 0; i < height; i++)
				buffer[halfsize + i] = u[i*width + c];
			
			if (boundary == 1)
				for (int i = 0; i < halfsize; i++)
					buffer[halfsize + height + i] = u[(height - i - 1)*width+c];
			else
				for (int i = 0; i < halfsize; i++)
					buffer[halfsize + height + i] = 0.0f;
			
			fiFloatBufferConvolution(buffer, kernel, height, ksize);
			
			for (int r = 0; r < height; r++)
				v[r*width+c] = buffer[r];
			
		}
		
		delete[] buffer;
	}
	
	
	
	void fiConvol(float *u,float *v,int width,int height,float *kernel,int kwidth,int kheight)
	{
		
		int K2 = kwidth / 2;
		int L2 = kheight / 2;
		
		for(int y=0 ; y < height; y++) 
			for (int x=0 ; x < width; x++) {
				
				float S = 0.0;
				
				for (int l = -L2; l <= L2; l++) 
					for (int k = -K2 ; k<= K2; k++)
					{ 
						int px=x+k;
						int py=y+l;
						
						if (px>=0 && px < width && py>=0 && py<height)
							S += u[width*py + px] * kernel[kwidth*(l+L2) + k+K2];
					}
				
				v[y*width+x] = (float) S;
				
			}
	}
	
	
	
	void fiSepConvol(float *u,float *v,int width,int height,float *xkernel, int xksize, float *ykernel, int yksize)
	{
		
		
		int boundary = 1;
		
		memcpy(v, u, width*height*sizeof(float));
		
		fiFloatHorizontalConvolution(v, v, width, height, xkernel, xksize, boundary);
		fiFloatVerticalVonvolution(v, v, width, height,  ykernel,  yksize, boundary);
		
	}
	
    
    
    
    void fiGaussianConvol(float *u, float *v, int width, int height, float sigma)
    {
        
        int ksize;	
        float *kernel;
        kernel = fiFloatGaussKernel(sigma,ksize);
        
        
        int boundary = 1;
        
        memcpy(v, u, width*height*sizeof(float));
        
        fiFloatHorizontalConvolution(v, v, width, height, kernel, ksize, boundary);
        fiFloatVerticalVonvolution(v, v, width, height,  kernel,  ksize, boundary);
        
        delete[] kernel;
        
    }
    

    
    
    
	
	////////////////////////////////////////////////////////////////////////////////
	//! End Float Pointer convolutions
	////////////////////////////////////////////////////////////////////////////////
	
	
	
	
	
	
	////////////////////////////////////////////////////////////////////////////////
	//! Begin Color Conversion
	////////////////////////////////////////////////////////////////////////////////
	
	
#define COEFF_YR 0.299
#define COEFF_YG 0.587
#define COEFF_YB 0.114
	
	
	/**
	 * \brief  RGV to YUV standard conversion
	 *
	 * Y = COEFF_YR * R + COEFF_YG  * G + COEFF_YB * B
	 *
	 * U = R - Y
	 *
	 * V = B - Y
	 *
	 * @param[in]  r, g, b  input image
	 * @param[out] y, u, v  yuv coordinates 
	 * @param[in]  width, height size of the image
	 *
	 */
	
	void fiRgb2Yuv(float *r,float *g,float *b,float *y,float *u,float *v,int width,int height) 
	{
		int size=height*width;
		
		for(int i=0;i<size;i++){
			y[i] = ( COEFF_YR *  r[i] + COEFF_YG * g[i] + COEFF_YB * b[i]);
			u[i] =  ( r[i] - y[i]);
			v[i] =  ( b[i] - y[i]);
		}
		
	}
	
	
	
	/**
	 * \brief   YUV to RGB standard conversion
	 *
	 *
	 * @param[in] y, u, v  yuv coordinates 
	 * @param[out]  r, g, b  ouput image
	 * @param[in]  width, height size of the image
	 *
	 */
	
	
	void fiYuv2Rgb(float *r,float *g,float *b,float *y,float *u,float *v, int width,int height)  
	{
		
		
		int iwh=height*width;
		
		for(int i=0;i<iwh;i++){
			
			g[i] =  ( y[i] - COEFF_YR * (u[i] + y[i]) - COEFF_YB * (v[i] +  y[i]) ) / COEFF_YG;
			r[i] =  ( u[i] + y[i]);
			b[i] =  ( v[i] + y[i]);
			
		}
		
	}
	
	
	
	
	
	/**
	 * \brief  RGV to YUV Orthogonal conversion
	 *
	 *
	 * @param[in]  r, g, b  input image
	 * @param[out] y, u, v  yuv coordinates 
	 * @param[in]  width, height size of the image
	 *
	 */
	
	void fiRgb2YuvO(float *r,float *g,float *b,float *y,float *u,float *v,int width,int height) 
	{
		int size=height*width;
		
		for(int i=0;i<size;i++)
		{
			y[i] =    0.577350 * r[i] + 0.577350 * g[i] + 0.577350  * b[i];
			u[i] =    0.707106 * r[i]					- 0.707106  * b[i];
			v[i] =    0.408248 * r[i] - 0.816496 * g[i]	+ 0.408248  * b[i];
		}
		
	}
	
	
	
	/**
	 * \brief   YUV Orthogonal to RGB conversion
	 *
	 *
	 * @param[in] y, u, v  yuv coordinates 
	 * @param[out]  r, g, b  ouput image
	 * @param[in]  width, height size of the image
	 *
	 */
	
	void fiYuvO2Rgb(float *r,float *g,float *b,float *y,float *u,float *v, int width,int height)  
	{
		
		
		int iwh=height*width;
		
		for(int i=0;i<iwh;i++)
		{
			
			r[i] =  0.577350 * y[i]	+ 0.707106 * u[i]	+  0.408248 * v[i];
			g[i] =  0.577350 * y[i]						-  0.816496 * v[i];
			b[i] =  0.577350 * y[i] - 0.707106 * u[i]	+  0.408248 * v[i];
			
		}
		
	}
	
	
	
    
    
    void fiImageDrawCircle(float *igray, int pi,int pj, double radius, float value, int width, int height)	
    {
        
        int mark = (int) rint(radius);
        double radius2 = radius * radius;
        
        for(int s = -mark ; s <= mark ;s++)
            for(int r = -mark ; r <= mark ;r++)
                if (pj+s>=0 && pi+r>= 0 && pj+s < height && pi+r < width && (double) (r*r + s*s) < radius2)
                {	
                    
                    int l = (pj+s)*width+pi+r;
                    igray[l] = value;
                }
        
    }
    
    
    void fiImageDrawLine(float *igray, int a0, int b0, int a1, int b1, float value, int width, int height)
    {
        
        int bdx,bdy;
        int sx,sy,dx,dy,x,y,z,l;
        
        bdx = width;
        bdy = height;
        
        if (a0 < 0) a0=0; 
        else if (a0>=bdx) a0=bdx-1;
        
        if (a1<0)  a1=0; 
        else  if (a1>=bdx)   a1=bdx-1;
        
        if (b0<0) b0=0; 
        else if (b0>=bdy) b0=bdy-1;
        
        if (b1<0) 	b1=0; 
        else if (b1>=bdy) b1=bdy-1; 
        
        if (a0<a1) { sx = 1; dx = a1-a0; } else { sx = -1; dx = a0-a1; }
        if (b0<b1) { sy = 1; dy = b1-b0; } else { sy = -1; dy = b0-b1; }
        x=0; y=0;
        
        if (dx>=dy) 
        {
            z = (-dx) / 2;
            while (abs(x) <= dx) 
            {
                
                l =  (y+b0)*bdx+x+a0; 
                
                igray[l] = value;
                
                x+=sx;
                z+=dy;
                if (z>0) { y+=sy; z-=dx; }
                
            } 
            
        }
        else 
        {
            z = (-dy) / 2;
            while (abs(y) <= dy) {
                
                l = (y+b0)*bdx+x+a0;
                igray[l] = value;
                
                y+=sy;
                z+=dx;
                if (z>0) { x+=sx; z-=dy; }
            }
        }
        
    }
    
    

    
    
    
	
	
	////////////////////////////////////////////////////////////////////////////////
	//! End Color Conversion
	////////////////////////////////////////////////////////////////////////////////
	

	
	////////////////////////////////////////////////////////////////////////////////
	//! Begin Spline Interpolation
	////////////////////////////////////////////////////////////////////////////////
	
	
	
	// extract image value (even outside image domain) 
	float v(float *in,int x,int y,float bg, int width, int height)
	{
		if (x<0 || x>=width || y<0 || y>=height)
			return(bg); else return(in[y*width+x]);
	}
	
	
	
	
	
	// c[] = values of interpolation function at ...,t-2,t-1,t,t+1,... 
	// coefficients for cubic interpolant (Keys' function)
	void keys(float *c,float t,float a)
	{
		float t2,at;
		
		t2 = t*t;
		at = a*t;
		c[0] = a*t2*(1.0-t);
		c[1] = (2.0*a+3.0 - (a+2.0)*t)*t2 - at;
		c[2] = ((a+2.0)*t - a-3.0)*t2 + 1.0;
		c[3] = a*(t-2.0)*t2 + at;
	}
	
	/* coefficients for cubic spline */
	void spline3(float *c,float t)
	{
		float tmp;
		
		tmp = 1.-t;
		c[0] = 0.1666666666*t*t*t;
		c[1] = 0.6666666666-0.5*tmp*tmp*(1.+t);
		c[2] = 0.6666666666-0.5*t*t*(2.-t);
		c[3] = 0.1666666666*tmp*tmp*tmp;
	}

	
	
	
	
	////////////////////// BEGIN   Any order
	
	
	/* pre-computation for spline of order >3 */
	void init_splinen(float *a,int n)
	{
		int k;
		
		a[0] = 1.;
		for (k=2;k<=n;k++) a[0]/=(float)k;
		for (k=1;k<=n+1;k++)
			a[k] = - a[k-1] *(float)(n+2-k)/(float)k;
	}
	
	/* fast integral power function */
	float ipow(float x,int n)
	{
		float res;
		
		for (res=1.;n;n>>=1) {
			if (n&1) res*=x;
			x*=x;
		}
		return(res);
	}
	
	/* coefficients for spline of order >3 */
	void splinen(float *c,float t,float *a,int n)
	{
		int i,k;
		float xn;
		
		memset((void *)c,0,(n+1)*sizeof(float));
		for (k=0;k<=n+1;k++) { 
			xn = ipow(t+(float)k,n);
			for (i=k;i<=n;i++) 
				c[i] += a[i-k]*xn;
		}
	}

	
	
	
	// called by invspline1d
	// takes c as input and output some kind of sum combining c and z
	double initcausal(double *c,int n,double z)
	{
		double zk,z2k,iz,sum;
		int k;
		
		zk = z; iz = 1./z;
		z2k = pow(z,(double)n-1.);
		sum = c[0] + z2k * c[n-1];
		z2k = z2k*z2k*iz;
		for (k=1;k<=n-2;k++) {
			sum += (zk+z2k)*c[k];
			zk *= z;
			z2k *= iz;
		}
		return (sum/(1.-zk*zk));
	}
	
	
	
	// called by invspline1d
	// takes c as input and output some kind of sum combining c and z
	double initanticausal(double *c,int n,double z)
	{
		return((z/(z*z-1.))*(z*c[n-2]+c[n-1]));
	}
	
	
	
	// called by  finvspline
	void invspline1D(double *c,int size,double *z,int npoles)
	{
		double lambda;
		int n,k;
		
		/* normalization */
		for (k=npoles,lambda=1.;k--;) lambda *= (1.-z[k])*(1.-1./z[k]);
		for (n=size;n--;) c[n] *= lambda;
		
		/*----- Loop on poles -----*/
		for (k=0;k<npoles;k++) {
			
			/* forward recursion */
			c[0] = initcausal(c,size,z[k]);
			for (n=1;n<size;n++) 
				c[n] += z[k]*c[n-1];
			
			/* backwards recursion */
			c[size-1] = initanticausal(c,size,z[k]);
			for (n=size-1;n--;) 
				c[n] = z[k]*(c[n+1]-c[n]);
			
		}
	}
	
	
	
	
	void finvspline(float *in,int order,float *out, int width, int height)
	{
		double *c,*d,z[5];
		int npoles,nx,ny,x,y;
		
		ny = height; nx = width;
		
		/* initialize poles of associated z-filter */
		switch (order) 
		{
			case 2: z[0]=-0.17157288;  /* sqrt(8)-3 */
				break;
				
			case 3: z[0]=-0.26794919;  /* sqrt(3)-2 */ 
				break;
				
			case 4: z[0]=-0.361341; z[1]=-0.0137254;
				break;
				
			case 5: z[0]=-0.430575; z[1]=-0.0430963;
				break;
				
			case 6: z[0]=-0.488295; z[1]=-0.0816793; z[2]=-0.00141415;
				break;
				
			case 7: z[0]=-0.53528; z[1]=-0.122555; z[2]=-0.00914869;
				break;
				
			case 8: z[0]=-0.574687; z[1]=-0.163035; z[2]=-0.0236323; z[3]=-0.000153821;
				break;
				
			case 9: z[0]=-0.607997; z[1]=-0.201751; z[2]=-0.0432226; z[3]=-0.00212131;
				break;
				
			case 10: z[0]=-0.636551; z[1]=-0.238183; z[2]=-0.065727; z[3]=-0.00752819;
				z[4]=-0.0000169828;
				break;
				
			case 11: z[0]=-0.661266; z[1]=-0.27218; z[2]=-0.0897596; z[3]=-0.0166696; 
				z[4]=-0.000510558;
				break;
				
			default:
				printf("finvspline: order should be in 2..11.\n");
				exit(-1);
		}
		
		npoles = order/2;
		
		/* initialize double array containing image */
		c = (double *)malloc(nx*ny*sizeof(double));
		d = (double *)malloc(nx*ny*sizeof(double));
		for (x=nx*ny;x--;) 
			c[x] = (double)in[x];
		
		/* apply filter on lines */
		for (y=0;y<ny;y++) 
			invspline1D(c+y*nx,nx,z,npoles);
		
		/* transpose */
		for (x=0;x<nx;x++)
			for (y=0;y<ny;y++) 
				d[x*ny+y] = c[y*nx+x];
		
		/* apply filter on columns */
		for (x=0;x<nx;x++) 
			invspline1D(d+x*ny,ny,z,npoles);
		
		/* transpose directy into image */
		for (x=0;x<nx;x++)
			for (y=0;y<ny;y++) 
				out[y*nx+x] = (float)(d[x*ny+y]);
		
		/* free array */
		free(d);
		free(c);
	}
	
	
	////////////////////// Any order
	
	

		
		
	
	////////////////////////////////////////////////////////////////////////////////
	//! End Spline Interpolation
	////////////////////////////////////////////////////////////////////////////////
	
	

	
	
	
	
	
	
	/**
	 * \brief   Tabulates exp(-x) function
	 *
	 *
	 * @param[in]  lut	vector
	 * @param[in]  size	length of the vector
	 *
	 */
	
	void  wxFillExpLut(float *lut, int size)
	{
		for(int i=0; i< size;i++)   lut[i]=   expf( - (float) i / LUTPRECISION);
	}
	
	
	
	
	/**
	 * \brief   Computes exp(-x) using lut table
	 *
	 *
	 * @param[in]  dif	value
	 * @param[in]  lut	lookup table
	 *
	 */
	float wxSLUT(float dif, float *lut)
	{
		
		if (dif >= (float) LUTMAXM1) return 0.0;
		
		int  x= (int) floor( (double) dif * (float) LUTPRECISION);
		
		float y1=lut[x];
		float y2=lut[x+1];
		
		return y1 + (y2-y1)*(dif*LUTPRECISION -  x); 
	}
	
	
	
	
	/**
	 * \brief   Compute euclidean distance of patches centered at (i0,j0) and (i1,j1) and size 2*radius+1 x 2*radius+1
	 *
	 *
	 * @param[in]  u0, u1  input images 
	 * @param[in]  i0,j0,i1,j1	coordinates of points
	 * @param[in]  radius	window of size 2*radius+1 x 2*radius+1 used
	 * @param[in]  channels	number or channels of the images
	 * @param[in]  width0, width1 width  of the images
	 *
	 */
	float fiL2FloatDist(float *u0,float *u1,int i0,int j0,int i1,int j1,int radius,int width0, int width1)
	{
		
		
		//if (radius == 1) 	return fiL2FloatDistR1(u0,u1,i0,j0,i1,j1,width0, width1);
		
		float dist=0.0;       
		for (int s=-radius; s<= radius; s++){
			
			int l = (j0+s)*width0 + (i0-radius);
			float *ptr0 = &u0[l];
			
			l = (j1+s)*width1 + (i1-radius);
			float *ptr1 = &u1[l];
			
			for(int r=-radius;r<=radius;r++,ptr0++,ptr1++){	float dif = (*ptr0 - *ptr1); dist += (dif*dif); }
			
		}
		
		return dist;
	}
	
	
	float fiL2FloatDist(float **u0,float **u1,int i0,int j0,int i1,int j1,int radius,int channels, int width0, int width1)
	{
		
		float dif = 0.0f;
		
		
		for (int ii=0; ii < channels; ii++) {
			
			dif += fiL2FloatDist(u0[ii],u1[ii],i0,j0,i1,j1,radius,width0, width1);
			
		}
		
		
		return dif;
	}
	

	
	
	
	
	float fiL2FloatWDist ( float * u0, float *u1, int i0, int j0,int i1,int j1,int radius, float *kernel, int width0, int width1)
	{
		
		float *ptrk=&kernel[0];
		float dist=0.0;       
		for (int s=-radius; s<= radius; s++){
			
			int l = (j0+s)*width0 + (i0-radius);
			float *ptr0 = &u0[l];
			
			l = (j1+s)*width1 + (i1-radius);
			float *ptr1 = &u1[l];
			
			
			for(int r=-radius;r<=radius;r++,ptr0++,ptr1++,ptrk++){ float dif = (*ptr0 - *ptr1); dist += *ptrk*(dif*dif); }
			
		}
		
		return dist;
	}
	
	
	
	
	float fiL2FloatWDist ( float * u0, float *u1, int i0, int j0,int i1,int j1,int xradius, int yradius, float *kernel, int width0, int width1)
	{
		
		float *ptrk=&kernel[0];
		float dist=0.0;       
		for (int s=-yradius; s<= yradius; s++){
			
			int l = (j0+s)*width0 + (i0-xradius);
			float *ptr0 = &u0[l];
			
			l = (j1+s)*width1 + (i1-xradius);
			float *ptr1 = &u1[l];
			
			
			for(int r=-xradius;r<=xradius;r++,ptr0++,ptr1++,ptrk++){ float dif = (*ptr0 - *ptr1); dist += *ptrk*(dif*dif); }
			
		}
		
		return dist;
	}
	
	
	
	/**
	 * \brief   Compute multichannel euclidean distance of patches centered at (i0,j0) and (i1,j1) and size 2*radius+1 x 2*radius+1
	 *
	 *
	 * @param[in]  u0, u1  input images 
	 * @param[in]  i0,j0,i1,j1	coordinates of points
	 * @param[in]  radius	window of size 2*radius+1 x 2*radius+1 used
	 * @param[in]  channels	number or channels of the images
	 * @param[in]  width0, width1 width  of the images
	 *
	 */
	float fiL2FloatWDist ( float ** u0, float **u1,int i0,int j0,int i1,int j1,int radius, float *kernel, int channels, int width0, int width1)
	{
		
		float dif = 0.0f;
		for (int ii=0; ii < channels; ii++) {
			
			dif += fiL2FloatWDist(u0[ii],u1[ii],i0,j0,i1,j1,radius,kernel,width0,width1);
			
		}
		
		dif /= (float) channels;
		
		return dif;
	}
	
	
	
	
}

