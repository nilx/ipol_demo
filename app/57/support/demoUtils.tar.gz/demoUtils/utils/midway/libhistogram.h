#ifndef _LIBHISTO_H_
#define _LIBHISTO_H_


#include "library.h"

namespace libIIP {
	
	
#define NB_CASES 500    
	
	
	
	
	
	/**
	 * \brief  Specificate two images to midway histogram (8 bit images)
	 *		 
	 * 
	 */
	
extern "C" 	{
	
	void fk_histogram_midway(float *in1, float *in2, float *out1, float *out2, int width1, int height1, int width2, int height2);
	
}
	
	
	/**
	 * \brief  Specificate a sequence of images to midway histogram (8 bit images)
	 *		 
	 * 
	 */
	
	void fk_histogram_midway_sequence(float **in, float **out, int nImages, int width, int height);
	
	
	
	
	
	/**
	 * \brief   Specificate second image to histogram of the first one (8 bit images)
	 *		   
	 */
	
	
	void fk_histogram_specification(float *in1, float *in2, float *out, int width1, int height1, int width2, int height2);
	
	
	
	
	
	
	/**
	 * \brief  Specificate histogram H to image (8 bit images)
	 *
	 */
	
	
	void fk_apply_histo(float *Histo,float *HistoInverse,int iRangeMax, float *src,float *srt, int width, int height);
	
	
	
	
	
	
	/**
	 * \brief  Compute accumulated histogram and inverse accumulated histogram (8 bit images)
	 *		   
	 */
	
	void fk_fill_histo(float *Histo,float *HistoInverse, int iRangeMax, float *in, int width, int height);
	
	
	
	
	
}

#endif
