#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#include "iio.h"

/*
Print help message
*/
void help(char *v[])
{
	printf("Usage: %s <argmin_map> <tilt_min> <tilt_max> <shear_min> <shear_max> <file_out>\n", v[0]);
}

/*
Function that take a 2-channels image of floats, with values on channel 1 in
[min1,max1] and on channel 2 in [min2,max2], and transform it to a hsv image
with hue in [h_min,h_max] and value in [v_min,v_max]

Convention about hsv images:
	hue between 0 and 360
	saturation between 0 and 1
	value between 0 and 1
*/
void compute_hsv(float *input, int w, int h, float min1, float max1,
				float h_min, float h_max, float min2, float max2, float v_min,
				float v_max, float *out_hsv)
{
	int pix=0;
	float a = (min1 == max1) ? 0 : (h_max-h_min)/(max1-min1);
	float b = (min2 == max2) ? 0 : (v_max-v_min)/(max2-min2);

	for (int row=0; row<h; row++)
		for (int col=0; col<w; col++)
		{
			pix = row*w+col;
			out_hsv[3*pix+0] = h_min+(input[2*pix+0]-min1)*a;
			out_hsv[3*pix+1] = 1;
			out_hsv[3*pix+2] = v_max-(max2-input[2*pix+1])*b; // opposed formulation, in order to get
			// a brighter image in the case of only one shear
		}
}

/*
Conversion of one pixel from hsv (in [0,360]x[0,1]x[0,1]) to rgb (in [O,255]³)
*/
void pix_conversion_hsv_to_rgb(float *in, float *out)
{
	float r, g, b, h, s, v; r=g=b=h=s=v=0;
	h = in[0]; s = in[1]; v = in[2];
	if (s == 0)
		r = g = b = v;
	else {
		int H = fmod(floor(h/60),6);
		float p, q, t, f = h/60 - H;
		p = v * (1 - s);
		q = v * (1 - f*s);
		t = v * (1 - (1 - f)*s);
		switch (H) {
			case 0: r = v; g = t; b = p; break;
			case 1: r = q; g = v; b = p; break;
			case 2: r = p; g = v; b = t; break;
			case 3: r = p; g = q; b = v; break;
			case 4: r = t; g = p; b = v; break;
			case 5: r = v; g = p; b = q; break;
			default: assert(false);
		}
	}
	out[0] = r*255.0; out[1] = g*255.0; out[2] = b*255.0;
}

/*
Conversion of an hsv image to rgb (same conventions as above)
*/
void hsv_to_rgb(float *in, int w, int h, float *out)
{
	int pix=0;
	for (int row=0; row<h; row++)
		for (int col=0; col<w; col++)
		{
			pix = row*w+col;
			pix_conversion_hsv_to_rgb(in+3*pix, out+3*pix);
			//in+3*pix is the address of the 3-cell array containing the 3-channels of the current pixel
		}
}


int main(int c, char *v[])
{
    if (c < 7)
    {
		help(v);
		return EXIT_FAILURE;
    }

    // Parameters loading
	float tilt_min = atof(v[2]);
	float tilt_max = atof(v[3]);
	float shear_min = atof(v[4]);
	float shear_max = atof(v[5]);
	char *file_out = v[6];

	int w, h, pd;

	//Read the input image
	float *input = iio_read_image_float_vec(v[1], &w, &h, &pd);

    // Memory allocations
    float *out_hsv = malloc(3*w*h*sizeof(float));
	float *out_rgb = malloc(3*w*h*sizeof(float));

	// Compute the hsv image by stretching the input data
	compute_hsv(input, w, h, tilt_min, tilt_max, 0, 120, shear_min, shear_max, 0.4, 0.8, out_hsv);

	// Convert hsv image into rgb
	hsv_to_rgb(out_hsv, w, h, out_rgb);

    // Write output images
    iio_save_image_float_vec(file_out, out_rgb, w, h, 3);
    iio_save_image_float_vec("out_hsv.tif", out_hsv, w, h, 3);


    // Free memory
	free(out_hsv);
    free(out_rgb);

    return EXIT_SUCCESS;
}
