#define _GNU_SOURCE // for function strndup in string.h

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "iio.h"

#define COST_MAX 1000000

/*
Function that returns a substring of length <len> from the input string,
starting from character number <begin>
*/
char * substring(const char *str, size_t begin, size_t len)
{
	if (str == 0 || strlen(str) == 0 || strlen(str) < begin || strlen(str) < (begin+len))
		return 0;

#ifdef _POSIX_C_SOURCE 
	return strndup(str + begin, len);
#else 
   // TODO: verify can it be done with ?
   // extern char *strncpy (char *__restrict __dest, __const char *__restrict __src, size_t __n)
   char *to = (char*) malloc(len+1);
   strncpy(to, str + begin, len);
	return to;
#endif

}

void help(char *v[])
{
	printf("Usage: %s <filt> ... <cost> ... <disp> ... <out_disp> <out_argmin> <out_cost>\n", v[0]);
    printf("The number of filt maps, cost maps and disp maps has to be equal\n");
	printf("All the input images have to be monochannel\n");
}



int main(int c, char *v[])
{
    if (c < 6)
    {
		help(v);
		return EXIT_FAILURE;
    }

    // Parameters loading
    int N = (c-4)/3; // Number of provided filters, cost maps and disp maps
    printf("%d input images\n",N);
	char *file_out_disp = v[c-3];
    char *file_out_argmin = v[c-2];
    char *file_out_cost = v[c-1];

	int w, h, pd;
	int pix;
	float tilt, shear;
	char *tilt_string, *shear_string;

	//Read the first input map to discover w and h
	float *filt = iio_read_image_float(v[1], &w, &h);
	float *cost;
	float *disp;

    // Memory allocations
    float *out_argmin = malloc(2*w*h*sizeof(float)); // 2-channels image to store shear and tilt
	float *out_cost = malloc(w*h*sizeof(float));
    float *out_disp = malloc(w*h*sizeof(float));

    /*
    Main loop
    */

    //Initialization
    for (int row=0; row<h; row++)
		for (int col=0; col<w; col++)
		{
			pix = row*w+col;
			out_argmin[2*pix] = 1; // tilt value;
			out_argmin[2*pix+1] = 0; // shear value
			out_cost[pix] = COST_MAX;
			out_disp[pix] = 0;

		}

	// Processing
	for (int i=0; i<N; i++)
	{
		printf("image %d\n",i);
		// Read the current filt,cost and disp
		filt = iio_read_image_float(v[i+1], &w, &h);
		cost = iio_read_image_float(v[N+i+1], &w, &h);
		disp = iio_read_image_float(v[2*N+i+1], &w, &h);

		// Read the tilt and shear parameters : parse the string v[3*i+1]
		// supposing that the names have the following format :
		// 		filt_t<tilt_value>_s<shear_value>.tif
		// 		mono_cost_t<tilt_value>_s<shear_value>.tif
		// 		disp_t<tilt_value>_s<shear_value>.tif
		// with %1.2f display style (ie like 0.00) for the numbers.
		// TO DO : Manage minus signe for negative shears
		tilt_string = substring(v[i+1], 6, 4);
		shear_string = substring(v[i+1], 12, 4);
		printf("tilt %s shear %s\n",tilt_string, shear_string);
		tilt = atof(tilt_string);
		shear = atof(shear_string);
		printf("tilt %1.2f shear %1.2f\n",tilt,shear);

		// For each pixel, compare the current cost to the previous best cost
		for (int row=0; row<h; row++)
			for (int col=0; col<w; col++)
			{
				pix = row*w+col;
				if (filt[pix]>0)
				{
					if (cost[pix] < out_cost[pix])
					{
						out_argmin[2*pix] = tilt;
						out_argmin[2*pix+1] = shear;
						out_cost[pix] = cost[pix];
						out_disp[pix] = disp[pix];
					}
				}
			}

	}

	/*
	End of main loop
	*/

    // Write output images
    iio_save_image_float_vec(file_out_argmin, out_argmin, w, h, 2);
    iio_save_image_float_vec(file_out_cost, out_cost, w, h, 1);
    iio_save_image_float_vec(file_out_disp, out_disp, w, h, 1);

    // Free memory
	free(filt);
    free(cost);
    free(disp);
    free(out_argmin);
	free(out_cost);
	free(out_disp);


    return EXIT_SUCCESS;
}
