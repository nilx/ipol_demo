#!/usr/bin/python

import os
import sys
import Image
import math

def run(cmd):
    """
    Print the provided command, then ask the shell to run it, and 
    print all the messages that would appear in the shell. It seems to
    wait that the command terminates.
    """
    print cmd
    fin, fout = os.popen4(cmd)
    print fout.read()

def main():
    """
    Computes the L2 distance between the input image and the same image after
    zoom_in and zoom_out
    """
    # verify input
    if len(sys.argv) == 3:
      input_file = sys.argv[1]
      zoom = float(sys.argv[2])
    else:
      print 'Incorrect syntax, use:'
      print '  > ' + sys.argv[0] + ' image zoom'
      sys.exit(1)
   
    # Do the job 
    im = Image.open(input_file)
    input_width = im.size[0] 
    tmp_width = int(zoom*input_width)
    blur_param = 0.8*math.sqrt((1/zoom)*(1/zoom)-1);
    run('zoom_1d %s tmp.tif %d'%(input_file,tmp_width))
    run('zoom_1d tmp.tif out.tif %d'%(input_width))
    run('blur %s reference.tif %f'%(input_file,blur_param))
    run('global_ssd %s out.tif'%(input_file))
    run('global_ssd reference.tif out.tif')

if __name__ == '__main__': main()
