#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "iio.h"

int main(int c, char *v[])
{
    if (c < 3)
    {
        printf("Usage: %s <image_1> <image_2>\n", v[0]);
	return EXIT_FAILURE;
    }

    // Parameters loading
    char *file_1 = v[1];
    char *file_2 = v[2];

    // Input image loading
    int w1, h1, pd1, w2, h2, pd2;
    float *im1 = iio_read_image_float_vec(file_1, &w1, &h1, &pd1);
    float *im2 = iio_read_image_float_vec(file_2, &w2, &h2, &pd2);
    if ((w1!=w2) || (h1!=h2) || (pd1!=pd2))
    {    
        printf("Error : the two images have don't have equal dimensions\n");
        return EXIT_FAILURE;
    }

    // Do the job
    float s=0;
    float tmp=0;
    int N=w1*h1*pd1;
    for (int i=0; i<N; i++)
    {
        tmp = im1[i]-im2[i];
        tmp *= tmp; 
        s += tmp;
    }
    s /= N;
    s = sqrtf(s);
    printf("%.02f\n",s);
    return EXIT_SUCCESS;
}

