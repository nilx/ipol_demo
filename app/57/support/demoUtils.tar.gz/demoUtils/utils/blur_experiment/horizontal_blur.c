#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <complex.h>
#include <fftw3.h>
#include "iio.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846264338327
#endif

/*
This function applies a horizontal blur to the mono-channel image stored at
address 'in', and write the result at address 'out'.
The width and height of input image are provided in parameters 'w' and
'h'. 

The transformed image is computed line by line. Each line of the input image
is blurred with a gaussian kernel of standard deviation s. The basic flow
of the algorithm is: for each line, symmetrize the signal by replicating it,
compute its DFT, then filter it with the gaussian kernel.
Then compute the inverse DFT of this resized vector and store the
result.
*/
void horizontal_blur(float *in, float *out, int w, int h, float s)
{
    // Length of the 1d signal
    int n = 2*w;

    // Memory allocation
    double *line_in = fftw_malloc(sizeof(double) * n);
    double *line_out = fftw_malloc(sizeof(double) * n);
    fftw_complex *dft = fftw_malloc(sizeof(fftw_complex) * (w+1));

    // Plans computation
    fftw_plan p_fwd = fftw_plan_dft_r2c_1d(n, line_in, dft, FFTW_ESTIMATE);
    fftw_plan p_back = fftw_plan_dft_c2r_1d(n, dft, line_out, FFTW_ESTIMATE);

    // Compute the output image row by row :
    for (int row = 0; row < h; row++)
    {
        // Copy and duplicate the current row, with symmetry towards the last term
        for (int i=0; i<w; i++)
        {
            line_in[i] = in[row*w+i];
            line_in[n-1-i] = in[row*w+i];
        }

        // Compute the DFT
        fftw_execute(p_fwd);

        // Filter the signal : each coefficient of the DFT is multiplied by
        // exp(-(1/2)*s*s*omega*omega) where omega is the pulsation
        // This is equivalent to convolve the trigonometric polynomial
        // with a gaussian of parameter s
        for (int k=1; k<=w; k++)
            dft[k] *= exp(-0.5*s*s*(k*2.0*M_PI/n)*(k*2.0*M_PI/n));
        
        // Normalize the DFT
        for (int i=0; i<=w; i++)
            dft[i] /= n;

        // Compute the iDFT to get the signal blurred 
        fftw_execute(p_back);

        // Copy blurred row in the output image (just the half that we need)
        for (int i=0; i<w; i++)
            out[row*w+i] = line_out[i];
    }

    // Free memory
    fftw_destroy_plan(p_fwd);
    fftw_destroy_plan(p_back);
    fftw_free(line_in);
    fftw_free(dft);
    fftw_free(line_out);
}

int main(int c, char *v[])
{
    if (c < 4)
    {
        printf("Usage: %s <input file> <output file> <blur std deviation>\n", v[0]);
	return EXIT_FAILURE;
    }

    // Parameters loading
    char *file_in = v[1];
    char *file_out = v[2];
    float s = atof(v[3]);

    // Input image loading
    int w, h, pd;
    float *input = iio_read_image_float_vec(file_in, &w, &h, &pd);
    printf("%d %d %d\n",w,h,pd);

    // Memory allocations
    float *output = malloc(w*h*pd*sizeof(float));
    float *in_ch = malloc(w*h*sizeof(float));
    float *out_ch = malloc(w*h*sizeof(float));

    // Image processing, channel by channel
    for (int channel=0; channel<pd; channel++)
    {
        // Copy the current channel
        for (int pix=0; pix<w*h; pix++)
            in_ch[pix] = input[pd*pix+channel];

        // Apply the transformation on the current channel
        horizontal_blur(in_ch, out_ch, w, h, s);

        // Copy the result in the out image :
        for (int pix=0; pix<w*h; pix++)
            output[pd*pix+channel] = out_ch[pix];
    }

    iio_save_image_float_vec(file_out, output, w, h, pd);

    // Free memory
    free(in_ch);
    free(out_ch);
    free(input);
    free(output);

    return EXIT_SUCCESS;
}
