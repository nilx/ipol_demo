#include <fftw3.h>
#include <math.h>

// DCT type I - direct and inverse
static void dctI_2d(float *fx, float *x, int w, int h)
{
   int i;
   float normalization_factor = sqrt(4*(w-1)*(h-1));
   float *a = fftwf_malloc(w*h*sizeof*a);
   fftwf_plan p = fftwf_plan_r2r_2d(h, w, a, fx,
         FFTW_REDFT00, FFTW_REDFT00, FFTW_ESTIMATE);
   for(i=0;i<w*h;i++) a[i] = x[i] / normalization_factor;
   fftwf_execute(p);
   fftwf_destroy_plan(p);
   fftwf_free(a);
   fftwf_cleanup();
}

// DCT type II - direct
static void dctII_2d(float *fx, float *x, int w, int h)
{
   int i;
   float normalization_factor = sqrt(w*h*4);
   float *a = fftwf_malloc(w*h*sizeof*a);
   fftwf_plan p = fftwf_plan_r2r_2d(h, w, a, fx,
         FFTW_REDFT10, FFTW_REDFT10, FFTW_ESTIMATE);
   for(i=0;i<w*h;i++) a[i] = x[i] / normalization_factor;
   fftwf_execute(p);
   fftwf_destroy_plan(p);
   fftwf_free(a);
   fftwf_cleanup();
}

// DCT type II - inverse
static void idctII_2d(float *x, float *fx, int w, int h)
{
   int i;
   float normalization_factor = sqrt(w*h*4);
   float *a = fftwf_malloc(w*h*sizeof*a);
   fftwf_plan p = fftwf_plan_r2r_2d(h, w, a, x,
         FFTW_REDFT01, FFTW_REDFT01, FFTW_ESTIMATE);
   for(i=0;i<w*h;i++) a[i] = fx[i] / normalization_factor;
   fftwf_execute(p);
   fftwf_destroy_plan(p);
   fftwf_free(a);
   fftwf_cleanup();
}

