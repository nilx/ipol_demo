/* normalize_histo_lib.c */
unsigned char *normalize_histo_u8(unsigned char *data, size_t size, unsigned char target_min, unsigned char target_max, size_t flat_nb_min, size_t flat_nb_max);
