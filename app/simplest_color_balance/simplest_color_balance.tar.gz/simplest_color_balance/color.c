/**
*  @brief computes the R G B components of the output image from its gray level 
*
*   Given a color image C=(R, G, B), given its gray level
*
* @f$ gray=0.3 R+0.6 G+ 0.1B \f$
*
* Given a modified gray image gray1
*
* This function compute an output color image C1=(R1,G1,B1) which each channel is proportinal 
* to the input channel and whose gray level is gray1, 
*
* @f$ R1=\frac{gray1}{gray} R    G1=\frac{gray1}{gray} G    B1= \frac{gray1}{gray} B \f$
*
*Note that we make a restriction and does not permit a factor less than 0.5 neither greater than 3

* @param data_out Output color image
* @param data input color image
* @param gray gray level of the input color image
* @param gray1 modified gray image
* @param dim size of the image
*
* @return data_out
*/

float *color(float *data_out, float *data, float *gray, float *gray1, size_t dim)
{
     
        float *ptr_red, *ptr_green, *ptr_blue;
        float *ptr_end,*ptr_gray, *ptr_gray1;
        float *ptr_in_red, *ptr_in_green, *ptr_in_blue;
        float A,B;
       
 /* sanity check*/
       if (NULL == data_out || NULL == data || NULL== gray || NULL== gray1)
       {
        fprintf(stderr, "a pointer is NULL and should not be so\n");
        abort();
       }

        

        ptr_red=data_out;
        ptr_green=data_out+dim;
        ptr_blue=data_out+2*dim;
        ptr_gray=gray;
        ptr_gray1=gray1;
        ptr_end=ptr_gray+dim;
        ptr_in_red=data; ptr_in_green=data+dim; ptr_in_blue=data+2*dim;
        while(ptr_gray< ptr_end){
           if(*ptr_gray <= 1.) *ptr_gray=1.;
           A=*ptr_gray1/ *ptr_gray;
           if(A > 3.) A=3.;
           if(A < 0.5) A=0.5;
           *ptr_red=A* (*ptr_in_red);
           *ptr_green=A*(*ptr_in_green);
           *ptr_blue=A*(*ptr_in_blue);
           if( *ptr_red > 255. || *ptr_green > 255. || *ptr_blue> 255.){
               B=*ptr_in_red;
               if(*ptr_in_green > B) B=*ptr_in_green;
               if( *ptr_in_blue > B) B=*ptr_in_blue;
               A= 255. /B;
               *ptr_red=A* (*ptr_in_red);
               *ptr_green=A*(*ptr_in_green);
               *ptr_blue=A*(*ptr_in_blue);
           }
           ptr_gray++; ptr_gray1++; ptr_red++; ptr_green++; ptr_blue++;
           ptr_in_red++;  ptr_in_green++; ptr_in_blue++;
        }
       return data_out;
}
